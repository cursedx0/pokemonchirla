/*    */ package viewControlerSprites;
/*    */ import java.util.HashMap;
/*    */ import java.util.Random;
/*    */ 
/*    */ public class Sprites {
/*  6 */   private static Sprites sprites = null;
/*    */   private HashMap<String, String> pokeMap;
/*  8 */   private Random rand = new Random();
/*    */   
/*    */   private Sprites() {
/* 11 */     this.pokeMap = new HashMap<>();
/* 12 */     this.pokeMap.put("TRAINER0", "/sprites/trainer0.png");
/* 13 */     this.pokeMap.put("TRAINER1", "/sprites/trainer1.png");
/* 14 */     this.pokeMap.put("TRAINER2", "/sprites/trainer2.png");
/* 15 */     this.pokeMap.put("TRAINER3", "/sprites/trainer3.png");
/* 16 */     this.pokeMap.put("TRAINER4", "/sprites/trainer4.png");
/* 17 */     this.pokeMap.put("TRAINER5", "/sprites/trainer5.png");
/* 18 */     this.pokeMap.put("ELECTRIC0", "/sprites/pikachu.png");
/* 19 */     this.pokeMap.put("ELECTRIC1", "/sprites/raichu.png");
/* 20 */     this.pokeMap.put("ELECTRIC2", "/sprites/raichu2.png");
/* 21 */     this.pokeMap.put("GRASS0", "/sprites/bulbasaur.png");
/* 22 */     this.pokeMap.put("GRASS1", "/sprites/ivysaur.png");
/* 23 */     this.pokeMap.put("GRASS2", "/sprites/venusaur.png");
/* 24 */     this.pokeMap.put("FIRE0", "/sprites/charmander.png");
/* 25 */     this.pokeMap.put("FIRE1", "/sprites/charmeleon.png");
/* 26 */     this.pokeMap.put("FIRE2", "/sprites/charizard.png");
/* 27 */     this.pokeMap.put("WATER0", "/sprites/squirtle.png");
/* 28 */     this.pokeMap.put("WATER1", "/sprites/wartortle.png");
/* 29 */     this.pokeMap.put("WATER2", "/sprites/blastoise.png");
/* 30 */     this.pokeMap.put("PSYCHIC0", "/sprites/abra.png");
/* 31 */     this.pokeMap.put("PSYCHIC1", "/sprites/kadabra.png");
/* 32 */     this.pokeMap.put("PSYCHIC2", "/sprites/alakazam.png");
/* 33 */     this.pokeMap.put("ROCK0", "/sprites/geodude.png");
/* 34 */     this.pokeMap.put("ROCK1", "/sprites/graveler.png");
/* 35 */     this.pokeMap.put("ROCK2", "/sprites/golem.png");
/* 36 */     this.pokeMap.put("FIGHTING0", "/sprites/machop.png");
/* 37 */     this.pokeMap.put("FIGHTING1", "/sprites/machoke.png");
/* 38 */     this.pokeMap.put("FIGHTING2", "/sprites/machamp.png");
/* 39 */     this.pokeMap.put("BUG0", "/sprites/caterpie.png");
/* 40 */     this.pokeMap.put("BUG1", "/sprites/metapod.png");
/* 41 */     this.pokeMap.put("BUG2", "/sprites/butterfree.png");
/* 42 */     this.pokeMap.put("GHOST0", "/sprites/gastly.png");
/* 43 */     this.pokeMap.put("GHOST1", "/sprites/haunter.png");
/* 44 */     this.pokeMap.put("GHOST2", "/sprites/gengar.png");
/* 45 */     this.pokeMap.put("DRAGON0", "/sprites/dratini.png");
/* 46 */     this.pokeMap.put("DRAGON1", "/sprites/dragonair.png");
/* 47 */     this.pokeMap.put("DRAGON2", "/sprites/dragonite.png");
/* 48 */     this.pokeMap.put("FLYING0", "/sprites/pidgey.png");
/* 49 */     this.pokeMap.put("FLYING1", "/sprites/pidgeotto.png");
/* 50 */     this.pokeMap.put("FLYING2", "/sprites/pidgeot.png");
/*    */   }
/*    */   
/*    */   public static Sprites getSprites() {
/* 54 */     if (sprites == null) {
/* 55 */       sprites = new Sprites();
/*    */     }
/* 57 */     return sprites;
/*    */   }
/*    */   
/*    */   public String getRandom() {
/* 61 */     Object[] values = this.pokeMap.values().toArray();
/* 62 */     String random = (String)values[this.rand.nextInt(values.length)];
/* 63 */     return random;
/*    */   }
/*    */   public String getByType(String t) {
/* 66 */     return this.pokeMap.get(t);
/*    */   }
/*    */ }


/* Location:              C:\User\\unaip\Downloads\PokémonBattleArena.jar!\viewControlerSprites\Sprites.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */