/*     */ package viewControlerSprites;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.GridLayout;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.util.Observable;
/*     */ import java.util.Observer;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JProgressBar;
/*     */ import javax.swing.JTextArea;
/*     */ import model.BattleManager;
/*     */ import model.MusicManager;
/*     */ import model.PlayerList;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PokePanel
/*     */   extends JPanel
/*     */   implements Observer
/*     */ {
/*     */   private JTextArea txtrAttack;
/*  28 */   private String info = "";
/*  29 */   private String image = null;
/*  30 */   private Controler controler = null;
/*     */   
/*     */   private boolean fainted = false;
/*     */   
/*     */   private int pIdx;
/*     */   private int idx;
/*     */   private JLabel label;
/*     */   private JProgressBar progressBar;
/*     */   private JPanel panelBar;
/*     */   private JProgressBar progressBar_Charged;
/*     */   
/*     */   public PokePanel(int pIdx, int idx) {
/*  42 */     setBackground(Color.WHITE);
/*  43 */     this.pIdx = pIdx;
/*  44 */     this.idx = idx;
/*  45 */     setLayout(new BorderLayout(0, 0));
/*  46 */     add(getTxtrAttack(), "North");
/*  47 */     add(getLabel(), "Center");
/*  48 */     add(getPanelBar(), "South");
/*  49 */     addMouseListener(getControler());
/*     */   }
/*     */   private JTextArea getTxtrAttack() {
/*  52 */     if (this.txtrAttack == null) {
/*  53 */       this.txtrAttack = new JTextArea();
/*  54 */       this.txtrAttack.addMouseListener(getControler());
/*  55 */       this.txtrAttack.setFont(new Font("DejaVu Sans Condensed", 0, 12));
/*  56 */       this.txtrAttack.setEditable(false);
/*  57 */       this.txtrAttack.setBackground(Color.WHITE);
/*  58 */       this.txtrAttack.setForeground(Color.BLACK);
/*  59 */       this.txtrAttack.setText("\n  att: ??\n  def: ??\n  health: ??\n  [|||    ]\n  type: unknown\n  status:unknown");
/*     */     } 
/*  61 */     return this.txtrAttack;
/*     */   }
/*     */   public void setLabelEnabled() {
/*  64 */     this.label.setEnabled(true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void update(Observable arg0, Object arg1) {
/*  70 */     String[] rr = (String[])arg1;
/*  71 */     int life = (int)(100.0F * Float.parseFloat(rr[2]) / Integer.parseInt(rr[3]));
/*  72 */     this.progressBar.setValue(life);
/*  73 */     if (life <= 50) {
/*  74 */       this.progressBar.setForeground(Color.ORANGE);
/*     */     }
/*  76 */     if (life <= 15) {
/*  77 */       this.progressBar.setForeground(Color.RED);
/*     */     }
/*  79 */     int chg = (int)(100.0F * Float.parseFloat(rr[7]) / Integer.parseInt(rr[6]));
/*  80 */     this.progressBar_Charged.setValue(chg);
/*  81 */     if (Integer.parseInt(rr[2]) >= 1) {
/*     */       
/*  83 */       if (chg == 100) {
/*  84 */         this.txtrAttack.setForeground(new Color(255, 99, 71));
/*     */       } else {
/*     */         
/*  87 */         this.txtrAttack.setForeground(Color.BLACK);
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/*  93 */       this.txtrAttack.setForeground(Color.WHITE);
/*  94 */       this.fainted = true;
/*  95 */       this.label.setEnabled(false);
/*     */     } 
/*     */     
/*  98 */     this.info = "\n  att: " + rr[0] + "\n  def: " + rr[1] + "\n  health: " + rr[2] + "/" + rr[3] + "\n  type: " + rr[4].toLowerCase();
/*  99 */     this.txtrAttack.setText(this.info);
/* 100 */     if (Integer.parseInt(rr[5]) != -1) {
/* 101 */       this.image = Sprites.getSprites().getByType(String.valueOf(rr[4]) + rr[5]);
/* 102 */       this.label.setIcon(new ImageIcon(PokePanel.class.getResource(this.image)));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Controler getControler() {
/* 114 */     if (this.controler == null) {
/* 115 */       this.controler = new Controler();
/*     */     }
/* 117 */     return this.controler;
/*     */   }
/*     */   public boolean isFainted() {
/* 120 */     return this.fainted;
/*     */   }
/*     */   
/*     */   public boolean isEnabled() {
/* 124 */     return this.label.isEnabled();
/*     */   }
/*     */   
/*     */   private class Controler implements MouseListener {
/*     */     public void mouseClicked(MouseEvent e) {
/* 129 */       MusicManager.getMusicManager().playEffect(0);
/* 130 */       if (e.getSource().equals(PokePanel.this.label) && PokePanel.this.label.isEnabled() && PlayerList.getPlayerList().getPosPlayer(PokePanel.this.pIdx).getTurn() && !(PlayerList.getPlayerList().getPosPlayer(PokePanel.this.pIdx) instanceof model.Bot)) {
/*     */         
/* 132 */         BattleManager.getBattleManager().setAttacksPlayer(PlayerList.getPlayerList().getPosPlayer(PokePanel.this.pIdx));
/* 133 */         BattleManager.getBattleManager().setAttacksPokemon(PlayerList.getPlayerList().getPosPlayer(PokePanel.this.pIdx).getPokemonList().getPokemonInPos(PokePanel.this.idx));
/* 134 */         System.out.println("setAttackPlayer " + PlayerList.getPlayerList().getPosPlayer(PokePanel.this.pIdx).getName() + " setAttackPoke " + PokePanel.this.idx);
/* 135 */         PokePanel.this.label.setEnabled(false);
/*     */       } else {
/*     */         
/* 138 */         BattleManager.getBattleManager().setDefendsPlayer(PlayerList.getPlayerList().getPosPlayer(PokePanel.this.pIdx));
/* 139 */         BattleManager.getBattleManager().setDefendsPokemon(PlayerList.getPlayerList().getPosPlayer(PokePanel.this.pIdx).getPokemonList().getPokemonInPos(PokePanel.this.idx));
/* 140 */         System.out.println("setDefendPlayer " + PlayerList.getPlayerList().getPosPlayer(PokePanel.this.pIdx).getName() + " setDefendPoke " + PokePanel.this.idx);
/* 141 */         BattleManager.getBattleManager().attack();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void mouseEntered(MouseEvent arg0) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void mouseExited(MouseEvent arg0) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void mousePressed(MouseEvent arg0) {}
/*     */ 
/*     */ 
/*     */     
/*     */     public void mouseReleased(MouseEvent arg0) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private JLabel getLabel() {
/* 167 */     if (this.label == null) {
/* 168 */       this.label = new JLabel("");
/*     */       
/* 170 */       this.label.setHorizontalAlignment(0);
/* 171 */       this.label.addMouseListener(getControler());
/*     */     } 
/* 173 */     return this.label;
/*     */   }
/*     */   private JProgressBar getProgressBar() {
/* 176 */     if (this.progressBar == null) {
/* 177 */       this.progressBar = new JProgressBar();
/* 178 */       this.progressBar.setStringPainted(true);
/* 179 */       this.progressBar.setString("health");
/* 180 */       this.progressBar.setForeground(new Color(138, 226, 52));
/* 181 */       this.progressBar.setBorderPainted(false);
/* 182 */       this.progressBar.setValue(100);
/*     */     } 
/* 184 */     return this.progressBar;
/*     */   }
/*     */   private JPanel getPanelBar() {
/* 187 */     if (this.panelBar == null) {
/* 188 */       this.panelBar = new JPanel();
/* 189 */       this.panelBar.setLayout(new GridLayout(2, 0, 0, 0));
/* 190 */       this.panelBar.add(getProgressBar());
/* 191 */       this.panelBar.add(getProgressBar_Charged());
/*     */     } 
/* 193 */     return this.panelBar;
/*     */   }
/*     */   private JProgressBar getProgressBar_Charged() {
/* 196 */     if (this.progressBar_Charged == null) {
/* 197 */       this.progressBar_Charged = new JProgressBar();
/* 198 */       this.progressBar_Charged.setForeground(new Color(255, 99, 71));
/* 199 */       this.progressBar_Charged.setString("charged attack");
/* 200 */       this.progressBar_Charged.setBorderPainted(false);
/* 201 */       this.progressBar_Charged.setStringPainted(true);
/*     */     } 
/* 203 */     return this.progressBar_Charged;
/*     */   }
/*     */ }


/* Location:              C:\User\\unaip\Downloads\PokémonBattleArena.jar!\viewControlerSprites\PokePanel.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */