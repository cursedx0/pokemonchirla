/*     */ package viewControlerSprites;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.EventQueue;
/*     */ import java.awt.Font;
/*     */ import java.awt.GridLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.util.Observable;
/*     */ import java.util.Observer;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTextField;
/*     */ import model.Game;
/*     */ import model.MusicManager;
/*     */ import model.PlayerList;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class MainBoard
/*     */   extends JFrame
/*     */   implements Observer
/*     */ {
/*     */   private JPanel playerNumPanel;
/*     */   private JLabel playerNumLabel;
/*     */   private JTextField playerNumTextField;
/*     */   private JLabel botNumLabel;
/*     */   private JTextField botNumTextField;
/*     */   private JPanel panel_1;
/*     */   private JPanel panel_3;
/*     */   private JPanel panel_4;
/*     */   private JPanel panel_5;
/*     */   private JPanel panel_6;
/*     */   private JPanel panel_7;
/*     */   private JPanel panel_8;
/*     */   private JLabel randomLabel;
/*     */   private JTextField randomTextField;
/*     */   private JLabel lblCardnum;
/*     */   private JTextField textField;
/*     */   private JButton btnReadme;
/*     */   private JButton btnStart;
/*     */   private JLabel lblEmail;
/*     */   private JPanel panel_2;
/*  48 */   private Controler controler = null;
/*     */   
/*     */   private JCheckBox chckbxHardMode;
/*     */   
/*     */   private JLabel label;
/*     */   
/*     */   private static MainBoard frame;
/*     */   
/*     */   public static void main(String[] args) {
/*  57 */     EventQueue.invokeLater(new Runnable()
/*     */         {
/*     */           public void run() {
/*     */             try {
/*  61 */               MainBoard.frame = new MainBoard();
/*  62 */               MainBoard.frame.setVisible(true);
/*  63 */               MusicManager.getMusicManager().playMusic(0);
/*  64 */             } catch (Exception e) {
/*  65 */               e.printStackTrace();
/*     */             } 
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MainBoard() {
/*  75 */     setForeground(Color.LIGHT_GRAY);
/*  76 */     setBackground(Color.WHITE);
/*  77 */     setTitle("p@kemon -Battle Arena-");
/*  78 */     getContentPane().setForeground(Color.LIGHT_GRAY);
/*  79 */     getContentPane().setBackground(Color.WHITE);
/*  80 */     getContentPane().add(getPlayerNumPanel(), "East");
/*  81 */     getContentPane().add(getLblEmail(), "South");
/*  82 */     getContentPane().add(getLabel_1(), "Center");
/*  83 */     setBounds(100, 100, 618, 314);
/*  84 */     setDefaultCloseOperation(3);
/*  85 */     Game.getGame().addObserver(this);
/*     */   }
/*     */   
/*     */   private JPanel getPlayerNumPanel() {
/*  89 */     if (this.playerNumPanel == null) {
/*  90 */       this.playerNumPanel = new JPanel();
/*  91 */       this.playerNumPanel.setForeground(Color.LIGHT_GRAY);
/*  92 */       this.playerNumPanel.setBackground(Color.WHITE);
/*  93 */       this.playerNumPanel.setLayout(new GridLayout(0, 2, 0, 0));
/*  94 */       this.playerNumPanel.add(getPlayerNumLabel());
/*  95 */       this.playerNumPanel.add(getPlayerNumTextField());
/*  96 */       this.playerNumPanel.add(getBotNumLabel());
/*  97 */       this.playerNumPanel.add(getBotNumTextField());
/*  98 */       this.playerNumPanel.add(getRandomLabel());
/*  99 */       this.playerNumPanel.add(getRandomTextField());
/* 100 */       this.playerNumPanel.add(getLblCardnum());
/* 101 */       this.playerNumPanel.add(getTextField());
/* 102 */       this.playerNumPanel.add(getPanel_1());
/* 103 */       this.playerNumPanel.add(getPanel_2());
/* 104 */       this.playerNumPanel.add(getPanel_3());
/* 105 */       this.playerNumPanel.add(getPanel_4());
/* 106 */       this.playerNumPanel.add(getPanel_5());
/* 107 */       this.playerNumPanel.add(getPanel_6());
/* 108 */       this.playerNumPanel.add(getPanel_7());
/* 109 */       this.playerNumPanel.add(getPanel_8());
/*     */     } 
/* 111 */     return this.playerNumPanel;
/*     */   }
/*     */   private JLabel getPlayerNumLabel() {
/* 114 */     if (this.playerNumLabel == null) {
/* 115 */       this.playerNumLabel = new JLabel("  players ");
/* 116 */       this.playerNumLabel.setHorizontalAlignment(0);
/* 117 */       this.playerNumLabel.setForeground(Color.BLACK);
/* 118 */       this.playerNumLabel.setBackground(Color.WHITE);
/*     */     } 
/* 120 */     return this.playerNumLabel;
/*     */   }
/*     */   private JTextField getPlayerNumTextField() {
/* 123 */     if (this.playerNumTextField == null) {
/* 124 */       this.playerNumTextField = new JTextField();
/* 125 */       this.playerNumTextField.setFont(new Font("Dialog", 1, 12));
/* 126 */       this.playerNumTextField.setForeground(Color.GREEN);
/* 127 */       this.playerNumTextField.setBackground(Color.GRAY);
/* 128 */       this.playerNumTextField.setHorizontalAlignment(0);
/* 129 */       this.playerNumTextField.setText("1");
/* 130 */       this.playerNumTextField.setColumns(1);
/*     */     } 
/* 132 */     return this.playerNumTextField;
/*     */   }
/*     */   private JLabel getBotNumLabel() {
/* 135 */     if (this.botNumLabel == null) {
/* 136 */       this.botNumLabel = new JLabel("  NPCs ");
/* 137 */       this.botNumLabel.setHorizontalAlignment(0);
/* 138 */       this.botNumLabel.setForeground(Color.BLACK);
/* 139 */       this.botNumLabel.setBackground(Color.WHITE);
/*     */     } 
/* 141 */     return this.botNumLabel;
/*     */   }
/*     */   private JTextField getBotNumTextField() {
/* 144 */     if (this.botNumTextField == null) {
/* 145 */       this.botNumTextField = new JTextField();
/* 146 */       this.botNumTextField.setFont(new Font("Dialog", 1, 12));
/* 147 */       this.botNumTextField.setForeground(Color.GREEN);
/* 148 */       this.botNumTextField.setBackground(Color.GRAY);
/* 149 */       this.botNumTextField.setHorizontalAlignment(0);
/* 150 */       this.botNumTextField.setText("2");
/* 151 */       this.botNumTextField.setColumns(1);
/*     */     } 
/* 153 */     return this.botNumTextField;
/*     */   }
/*     */   private JPanel getPanel_1() {
/* 156 */     if (this.panel_1 == null) {
/* 157 */       this.panel_1 = new JPanel();
/* 158 */       this.panel_1.setForeground(Color.LIGHT_GRAY);
/* 159 */       this.panel_1.setBackground(Color.WHITE);
/*     */     } 
/* 161 */     return this.panel_1;
/*     */   }
/*     */   private JPanel getPanel_3() {
/* 164 */     if (this.panel_3 == null) {
/* 165 */       this.panel_3 = new JPanel();
/* 166 */       this.panel_3.setForeground(Color.LIGHT_GRAY);
/* 167 */       this.panel_3.setBackground(Color.WHITE);
/*     */     } 
/* 169 */     return this.panel_3;
/*     */   }
/*     */   private JPanel getPanel_4() {
/* 172 */     if (this.panel_4 == null) {
/* 173 */       this.panel_4 = new JPanel();
/* 174 */       this.panel_4.setForeground(Color.LIGHT_GRAY);
/* 175 */       this.panel_4.setBackground(Color.WHITE);
/*     */     } 
/* 177 */     return this.panel_4;
/*     */   }
/*     */   private JPanel getPanel_5() {
/* 180 */     if (this.panel_5 == null) {
/* 181 */       this.panel_5 = new JPanel();
/* 182 */       this.panel_5.setForeground(Color.LIGHT_GRAY);
/* 183 */       this.panel_5.setBackground(Color.WHITE);
/*     */     } 
/* 185 */     return this.panel_5;
/*     */   }
/*     */   private JPanel getPanel_6() {
/* 188 */     if (this.panel_6 == null) {
/* 189 */       this.panel_6 = new JPanel();
/* 190 */       this.panel_6.setForeground(Color.LIGHT_GRAY);
/* 191 */       this.panel_6.setBackground(Color.WHITE);
/* 192 */       this.panel_6.add(getBtnReadme());
/*     */     } 
/* 194 */     return this.panel_6;
/*     */   }
/*     */   private JPanel getPanel_7() {
/* 197 */     if (this.panel_7 == null) {
/* 198 */       this.panel_7 = new JPanel();
/* 199 */       this.panel_7.setForeground(Color.LIGHT_GRAY);
/* 200 */       this.panel_7.setBackground(Color.WHITE);
/*     */     } 
/* 202 */     return this.panel_7;
/*     */   }
/*     */   private JPanel getPanel_8() {
/* 205 */     if (this.panel_8 == null) {
/* 206 */       this.panel_8 = new JPanel();
/* 207 */       this.panel_8.setForeground(Color.LIGHT_GRAY);
/* 208 */       this.panel_8.setBackground(Color.WHITE);
/* 209 */       this.panel_8.add(getBtnStart());
/*     */     } 
/* 211 */     return this.panel_8;
/*     */   }
/*     */   private JLabel getRandomLabel() {
/* 214 */     if (this.randomLabel == null) {
/* 215 */       this.randomLabel = new JLabel("miliSecs/round");
/* 216 */       this.randomLabel.setHorizontalAlignment(0);
/* 217 */       this.randomLabel.setForeground(Color.BLACK);
/* 218 */       this.randomLabel.setBackground(Color.WHITE);
/*     */     } 
/* 220 */     return this.randomLabel;
/*     */   }
/*     */   private JTextField getRandomTextField() {
/* 223 */     if (this.randomTextField == null) {
/* 224 */       this.randomTextField = new JTextField();
/* 225 */       this.randomTextField.setFont(new Font("Dialog", 1, 12));
/* 226 */       this.randomTextField.setForeground(Color.GREEN);
/* 227 */       this.randomTextField.setBackground(Color.GRAY);
/* 228 */       this.randomTextField.setHorizontalAlignment(0);
/* 229 */       this.randomTextField.setText("2000");
/* 230 */       this.randomTextField.setColumns(3);
/*     */     } 
/* 232 */     return this.randomTextField;
/*     */   }
/*     */   private JLabel getLblCardnum() {
/* 235 */     if (this.lblCardnum == null) {
/* 236 */       this.lblCardnum = new JLabel("  PoKéMoNs ");
/* 237 */       this.lblCardnum.setBackground(Color.WHITE);
/* 238 */       this.lblCardnum.setForeground(Color.BLACK);
/* 239 */       this.lblCardnum.setHorizontalAlignment(0);
/*     */     } 
/* 241 */     return this.lblCardnum;
/*     */   }
/*     */   private JTextField getTextField() {
/* 244 */     if (this.textField == null) {
/* 245 */       this.textField = new JTextField();
/* 246 */       this.textField.setFont(new Font("Dialog", 1, 12));
/* 247 */       this.textField.setBackground(Color.GRAY);
/* 248 */       this.textField.setForeground(Color.GREEN);
/* 249 */       this.textField.setHorizontalAlignment(0);
/* 250 */       this.textField.setText("3");
/* 251 */       this.textField.setColumns(10);
/*     */     } 
/* 253 */     return this.textField;
/*     */   }
/*     */   private JButton getBtnReadme() {
/* 256 */     if (this.btnReadme == null) {
/* 257 */       this.btnReadme = new JButton("readMe");
/* 258 */       this.btnReadme.addActionListener(new ActionListener()
/*     */           {
/*     */             public void actionPerformed(ActionEvent arg0) {
/* 261 */               MusicManager.getMusicManager().playEffect(0);
/* 262 */               (new ReadMe()).setVisible(true);
/*     */             }
/*     */           });
/* 265 */       this.btnReadme.setForeground(Color.ORANGE);
/* 266 */       this.btnReadme.setBackground(Color.DARK_GRAY);
/*     */     } 
/* 268 */     return this.btnReadme;
/*     */   }
/*     */   private JButton getBtnStart() {
/* 271 */     if (this.btnStart == null) {
/* 272 */       this.btnStart = new JButton("free4all");
/* 273 */       this.btnStart.addActionListener(getControler());
/* 274 */       this.btnStart.setForeground(Color.GREEN);
/* 275 */       this.btnStart.setBackground(Color.DARK_GRAY);
/*     */     } 
/* 277 */     return this.btnStart;
/*     */   }
/*     */   private JLabel getLblEmail() {
/* 280 */     if (this.lblEmail == null) {
/* 281 */       this.lblEmail = new JLabel("ander.barrena@ehu.eus");
/* 282 */       this.lblEmail.setFont(new Font("FreeSans", 0, 11));
/* 283 */       this.lblEmail.setForeground(Color.BLACK);
/* 284 */       this.lblEmail.setBackground(Color.LIGHT_GRAY);
/* 285 */       this.lblEmail.setHorizontalAlignment(0);
/*     */     } 
/* 287 */     return this.lblEmail;
/*     */   }
/*     */   private JPanel getPanel_2() {
/* 290 */     if (this.panel_2 == null) {
/* 291 */       this.panel_2 = new JPanel();
/* 292 */       this.panel_2.setBackground(Color.WHITE);
/* 293 */       this.panel_2.add(getChckbxHardMode());
/*     */     } 
/* 295 */     return this.panel_2;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void update(Observable arg0, Object arg1) {
/* 301 */     Object[] rr = (Object[])arg1;
/* 302 */     PlayerBoard pb = new PlayerBoard(((Integer)rr[0]).intValue(), (String)rr[1], ((Integer)rr[2]).intValue());
/*     */     
/* 304 */     String pName = (String)rr[1];
/* 305 */     PlayerList.getPlayerList().findName(pName).addObserver(pb);
/* 306 */     for (int i = 0; i < Integer.parseInt(this.textField.getText()); i++) {
/* 307 */       PlayerList.getPlayerList().findName(pName).getPokemonList().getPokemonInPos(i).addObserver((Observer)pb.getCardsPanel().getComponent(i));
/* 308 */       PlayerList.getPlayerList().findName(pName).updatePokemons();
/*     */     } 
/* 310 */     pb.setVisible(true);
/*     */   }
/*     */   
/*     */   private Controler getControler() {
/* 314 */     if (this.controler == null) {
/* 315 */       this.controler = new Controler();
/*     */     }
/* 317 */     return this.controler;
/*     */   }
/*     */   
/*     */   private class Controler implements ActionListener {
/*     */     public void actionPerformed(ActionEvent e) {
/* 322 */       if (e.getSource().equals(MainBoard.this.btnStart)) {
/* 323 */         Game.getGame().initPlayers(Integer.parseInt(MainBoard.this.playerNumTextField.getText()), Integer.parseInt(MainBoard.this.botNumTextField.getText()), Integer.parseInt(MainBoard.this.randomTextField.getText()), Integer.parseInt(MainBoard.this.textField.getText()));
/* 324 */         MusicManager.getMusicManager().playEffect(0);
/* 325 */         MusicManager.getMusicManager().playMusic(1);
/* 326 */         Game.getGame().startGame();
/* 327 */         MainBoard.frame.setVisible(false);
/*     */       } 
/*     */     } }
/*     */   
/*     */   private JCheckBox getChckbxHardMode() {
/* 332 */     if (this.chckbxHardMode == null) {
/* 333 */       this.chckbxHardMode = new JCheckBox("hard mode");
/* 334 */       this.chckbxHardMode.setVisible(false);
/* 335 */       this.chckbxHardMode.setBackground(Color.WHITE);
/*     */     } 
/* 337 */     return this.chckbxHardMode;
/*     */   }
/*     */   private JLabel getLabel_1() {
/* 340 */     if (this.label == null) {
/* 341 */       ImageIcon image = new ImageIcon(getClass().getResource("/sprites/main.png"));
/* 342 */       this.label = new JLabel(image);
/* 343 */       this.label.setHorizontalAlignment(0);
/*     */     } 
/* 345 */     return this.label;
/*     */   }
/*     */ }


/* Location:              C:\User\\unaip\Downloads\PokémonBattleArena.jar!\viewControlerSprites\MainBoard.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */