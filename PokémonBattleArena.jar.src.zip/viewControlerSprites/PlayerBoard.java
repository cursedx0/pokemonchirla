/*     */ package viewControlerSprites;
/*     */ 
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.EventQueue;
/*     */ import java.awt.GridLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Observable;
/*     */ import java.util.Observer;
/*     */ import java.util.Random;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import model.BattleManager;
/*     */ import model.Game;
/*     */ import model.MusicManager;
/*     */ import model.PlayerList;
/*     */ import model.poke.PokeFactory;
/*     */ import model.poke.PokeType;
/*     */ import model.poke.Pokemon;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class PlayerBoard
/*     */   extends JFrame
/*     */   implements Observer
/*     */ {
/*  34 */   private static int xPos = 400;
/*  35 */   private static int yPos = 400;
/*     */   private JPanel cardsPanel;
/*     */   private JPanel itemPanel;
/*     */   private JLabel lblWait;
/*     */   private JButton btnSwitchX;
/*  40 */   private Controler controler = null;
/*  41 */   private Random random = new Random();
/*     */   private int pIdx;
/*     */   private String playerName;
/*  44 */   private ArrayList<PokePanel> cpList = new ArrayList<>();
/*     */ 
/*     */   
/*     */   private JLabel trainerLabel;
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/*  51 */     EventQueue.invokeLater(new Runnable()
/*     */         {
/*     */           public void run() {
/*     */             try {
/*  55 */               PlayerBoard frame = new PlayerBoard(0, "TrainerXY", 3);
/*  56 */               frame.setVisible(true);
/*  57 */             } catch (Exception e) {
/*  58 */               e.printStackTrace();
/*     */             } 
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PlayerBoard(int pIdx, String pName, int pNumAsciiMon) {
/*  68 */     this.pIdx = pIdx;
/*  69 */     this.playerName = pName;
/*  70 */     setForeground(Color.WHITE);
/*  71 */     setTitle(pName);
/*  72 */     setBackground(Color.WHITE);
/*  73 */     getContentPane().setBackground(Color.GRAY);
/*  74 */     setBounds(xPos, yPos, 80 + pNumAsciiMon * 150, 274);
/*     */     
/*  76 */     xPos += 20;
/*  77 */     yPos -= 20;
/*  78 */     setDefaultCloseOperation(3);
/*  79 */     getContentPane().setLayout(new BorderLayout(0, 0));
/*  80 */     getContentPane().add(getCardsPanel(), "Center");
/*  81 */     getCardsPanel().setLayout(new GridLayout(0, pNumAsciiMon, 1, 1));
/*     */     
/*  83 */     getContentPane().add(getItemPanel(), "West");
/*  84 */     for (int x = 0; x < pNumAsciiMon; x++) {
/*  85 */       PokePanel cp = new PokePanel(pIdx, x);
/*  86 */       getCardsPanel().add(cp);
/*  87 */       this.cpList.add(cp);
/*     */     } 
/*     */   }
/*     */   
/*     */   public JPanel getCardsPanel() {
/*  92 */     if (this.cardsPanel == null) {
/*  93 */       this.cardsPanel = new JPanel();
/*  94 */       this.cardsPanel.setBackground(Color.LIGHT_GRAY);
/*     */     } 
/*  96 */     return this.cardsPanel;
/*     */   }
/*     */   private JPanel getItemPanel() {
/*  99 */     if (this.itemPanel == null) {
/* 100 */       this.itemPanel = new JPanel();
/* 101 */       this.itemPanel.setBackground(Color.WHITE);
/* 102 */       this.itemPanel.setLayout(new BorderLayout(0, 0));
/* 103 */       this.itemPanel.add(getLblWait(), "North");
/* 104 */       this.itemPanel.add(getBtnSwitchX(), "South");
/* 105 */       this.itemPanel.add(getTrainerLabel(), "Center");
/*     */     } 
/* 107 */     return this.itemPanel;
/*     */   }
/*     */   private JLabel getLblWait() {
/* 110 */     if (this.lblWait == null) {
/* 111 */       this.lblWait = new JLabel("  wait  ");
/* 112 */       this.lblWait.setHorizontalAlignment(0);
/* 113 */       this.lblWait.setOpaque(true);
/* 114 */       this.lblWait.setBackground(Color.RED);
/* 115 */       this.lblWait.setForeground(Color.WHITE);
/* 116 */       this.lblWait.addMouseListener(getControler());
/*     */     } 
/* 118 */     return this.lblWait;
/*     */   }
/*     */   private JButton getBtnSwitchX() {
/* 121 */     if (this.btnSwitchX == null) {
/* 122 */       this.btnSwitchX = new JButton("change x3");
/* 123 */       this.btnSwitchX.setVisible(false);
/* 124 */       this.btnSwitchX.setBackground(Color.DARK_GRAY);
/* 125 */       this.btnSwitchX.setForeground(Color.ORANGE);
/* 126 */       this.btnSwitchX.addActionListener(getControler());
/* 127 */       if (this.playerName.matches("npc@TraiNer(.*)")) this.btnSwitchX.setVisible(false); 
/*     */     } 
/* 129 */     return this.btnSwitchX;
/*     */   }
/*     */   public String getPlayerName() {
/* 132 */     return this.playerName;
/*     */   }
/*     */ 
/*     */   
/*     */   public void update(Observable arg0, Object arg1) {
/* 137 */     Object[] rr = (Object[])arg1;
/* 138 */     if (!this.btnSwitchX.getText().contentEquals("change x" + ((Integer)rr[1]).intValue())) {
/* 139 */       this.btnSwitchX.setText("change x" + ((Integer)rr[1]).intValue());
/*     */     }
/* 141 */     else if (((Boolean)rr[0]).booleanValue()) {
/* 142 */       if (PlayerList.getPlayerList().thereIsWinner()) {
/* 143 */         this.lblWait.setText("  winner!  ");
/*     */       } else {
/*     */         
/* 146 */         this.lblWait.setText("  g@!  \n");
/*     */       } 
/* 148 */       this.lblWait.setBackground(Color.GREEN);
/* 149 */       this.lblWait.setForeground(Color.BLACK);
/* 150 */       this.cpList.stream().filter(p -> !p.isFainted()).forEach(p -> p.setLabelEnabled());
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */ 
/*     */       
/* 159 */       if (PlayerList.getPlayerList().getPosPlayer(this.pIdx).getDefeated()) {
/* 160 */         this.lblWait.setText("defeated");
/*     */       } else {
/*     */         
/* 163 */         this.lblWait.setText("  wait  \n");
/*     */       } 
/* 165 */       this.lblWait.setBackground(Color.RED);
/* 166 */       this.lblWait.setForeground(Color.WHITE);
/*     */     } 
/*     */   }
/*     */   
/*     */   private Controler getControler() {
/* 171 */     if (this.controler == null) {
/* 172 */       this.controler = new Controler();
/*     */     }
/* 174 */     return this.controler;
/*     */   }
/*     */   
/*     */   private class Controler implements ActionListener, MouseListener {
/*     */     public void actionPerformed(ActionEvent e) {
/* 179 */       if (e.getSource().equals(PlayerBoard.this.btnSwitchX) && BattleManager.getBattleManager().getAttacksPokemon() != null) {
/* 180 */         Pokemon attacks = BattleManager.getBattleManager().getAttacksPokemon();
/* 181 */         Pokemon pk = PokeFactory.getPokeFactory().createPokemon(PokeType.values()[(new Random()).nextInt((PokeType.values()).length)], attacks.getPos());
/* 182 */         pk.addObserver((Observer)PlayerBoard.this.cardsPanel.getComponent(attacks.getPos()));
/* 183 */         PlayerList.getPlayerList().getPosPlayer(PlayerBoard.this.pIdx).changePoke(attacks, pk);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*     */     public void mouseClicked(MouseEvent arg0) {
/* 189 */       if (PlayerList.getPlayerList().getPosPlayer(PlayerBoard.this.pIdx).getTurn() && !(PlayerList.getPlayerList().getPosPlayer(PlayerBoard.this.pIdx) instanceof model.Bot)) {
/* 190 */         MusicManager.getMusicManager().playEffect(0);
/* 191 */         Game.getGame().startGame();
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void mouseEntered(MouseEvent arg0) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void mouseExited(MouseEvent arg0) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void mousePressed(MouseEvent arg0) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void mouseReleased(MouseEvent arg0) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private JLabel getTrainerLabel() {
/* 220 */     if (this.trainerLabel == null) {
/* 221 */       this.trainerLabel = new JLabel("");
/* 222 */       String image = Sprites.getSprites().getByType("TRAINER" + this.random.nextInt(6));
/* 223 */       this.trainerLabel.setIcon(new ImageIcon(PokePanel.class.getResource(image)));
/*     */     } 
/* 225 */     return this.trainerLabel;
/*     */   }
/*     */ }


/* Location:              C:\User\\unaip\Downloads\PokémonBattleArena.jar!\viewControlerSprites\PlayerBoard.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */