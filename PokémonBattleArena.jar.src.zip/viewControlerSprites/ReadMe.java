/*    */ package viewControlerSprites;
/*    */ 
/*    */ import java.awt.BorderLayout;
/*    */ import java.awt.Color;
/*    */ import java.awt.EventQueue;
/*    */ import java.awt.Font;
/*    */ import javax.swing.JFrame;
/*    */ import javax.swing.JPanel;
/*    */ import javax.swing.JTextPane;
/*    */ import javax.swing.border.EmptyBorder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ReadMe
/*    */   extends JFrame
/*    */ {
/*    */   private JPanel contentPane;
/*    */   private JTextPane txtpnFreeallAllVersus;
/*    */   
/*    */   public static void main(String[] args) {
/* 23 */     EventQueue.invokeLater(new Runnable()
/*    */         {
/*    */           public void run() {
/*    */             try {
/* 27 */               ReadMe frame = new ReadMe();
/* 28 */               frame.setVisible(true);
/* 29 */             } catch (Exception e) {
/* 30 */               e.printStackTrace();
/*    */             } 
/*    */           }
/*    */         });
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ReadMe() {
/* 40 */     setFont(new Font("Ubuntu Mono", 0, 12));
/* 41 */     setBackground(Color.LIGHT_GRAY);
/* 42 */     setTitle("readMe");
/* 43 */     setBounds(100, 100, 428, 586);
/* 44 */     this.contentPane = new JPanel();
/* 45 */     this.contentPane.setBackground(Color.LIGHT_GRAY);
/* 46 */     this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
/* 47 */     this.contentPane.setLayout(new BorderLayout(0, 0));
/* 48 */     setContentPane(this.contentPane);
/* 49 */     this.contentPane.add(getTxtpnFreeallAllVersus(), "Center");
/*    */   }
/*    */   private JTextPane getTxtpnFreeallAllVersus() {
/* 52 */     if (this.txtpnFreeallAllVersus == null) {
/* 53 */       this.txtpnFreeallAllVersus = new JTextPane();
/* 54 */       this.txtpnFreeallAllVersus.setFont(new Font("Liberation Sans", 0, 12));
/* 55 */       this.txtpnFreeallAllVersus.setForeground(Color.DARK_GRAY);
/* 56 */       this.txtpnFreeallAllVersus.setBackground(Color.WHITE);
/* 57 */       this.txtpnFreeallAllVersus.setText(" PoKéMoN -Battle Arena-\n\n* free4all: all versus all game\n  * (x) players using (y) pokéMons each\n* pokeMons stats and types are assigned at random\n  * pokeMon types and effects\n\t* fire extra damage to grass/bug\n\t* grass extra damage to rock/water\n\t* water extra damage to fire/rock\n\t* electric extra damage to water/flying\n\t* bug extra damage to grass/phychic\n\t* psychic extra damage to fighting\n\t* fighting extra damage to rock\n\t* rock extra damage to electric/bug/fire\n\t* ghost extra damage to ghost/psychic\n\t* dragon extra damage to dragon\n\t* flying extra damage to bug/fighting/grass\n\n  * stats\n\t* att: base damage with normal attack (10-13)\n\t* def: base defense (5-9)\n\t* health: pokéMon health (80-100)\n\n* wait until your turn (random across players)\n   there is a posibility to play 2,3,4 turns in a row\n   each turn you can:\n   * attack foreach of your pokeMon\n\t* damage = att*effect - def\n* evolutions\n  * your pokéMon will evolve at health %50 and %20 repectively\n\t   each evolution step will boost pokéMon stats\n* charged attack\n  * pokemon will perform a charged attack when itrecieves a\n\t   determined amount of attacks \n  * when charged, pokêMon will gain +100 att +100 def until it\n\t   performs the charged attack\n* all attacks are executed at the moment\n* once you are done click on g@! and wait until your next turn\n\n\n");
/*    */     } 
/* 59 */     return this.txtpnFreeallAllVersus;
/*    */   }
/*    */ }


/* Location:              C:\User\\unaip\Downloads\PokémonBattleArena.jar!\viewControlerSprites\ReadMe.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */