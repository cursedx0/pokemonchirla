/*    */ package model;
/*    */ import javax.sound.sampled.AudioInputStream;
/*    */ import javax.sound.sampled.AudioSystem;
/*    */ import javax.sound.sampled.Clip;
/*    */ 
/*    */ public class MusicManager {
/*  7 */   private static MusicManager musicManager = null;
/*  8 */   private Clip clip = null;
/*  9 */   private Clip fclip = null;
/*    */   
/*    */   private AudioInputStream audioIn;
/*    */   private AudioInputStream faudioIn;
/*    */   
/*    */   public static MusicManager getMusicManager() {
/* 15 */     if (musicManager == null) {
/* 16 */       musicManager = new MusicManager();
/*    */     }
/* 18 */     return musicManager;
/*    */   }
/*    */   public synchronized void playEffect(int pSound) {
/* 21 */     if (this.fclip != null) {
/* 22 */       this.fclip.stop();
/* 23 */       this.fclip.flush();
/* 24 */       this.fclip.close();
/* 25 */     }  String pFile = "";
/* 26 */     if (pSound == 0) {
/* 27 */       pFile = "/sound_wav/press.wav";
/*    */     }
/*    */ 
/*    */ 
/*    */     
/*    */     try {
/* 33 */       this.audioIn = AudioSystem.getAudioInputStream(getClass().getResource(pFile));
/* 34 */       this.fclip = AudioSystem.getClip();
/* 35 */       this.fclip.open(this.faudioIn);
/*    */       
/* 37 */       this.fclip.start();
/* 38 */       this.fclip.wait();
/* 39 */     } catch (Exception exception) {}
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public synchronized void playMusic(int pSound) {
/* 46 */     if (this.clip != null) {
/* 47 */       this.clip.stop();
/* 48 */       this.clip.flush();
/* 49 */       this.clip.close();
/*    */     } 
/* 51 */     String pFile = "";
/* 52 */     if (pSound == 0) {
/* 53 */       pFile = "/sound_wav/opening.wav";
/*    */     }
/* 55 */     if (pSound == 1) {
/* 56 */       pFile = "/sound_wav/battle.wav";
/*    */     }
/* 58 */     if (pSound == 2) {
/* 59 */       pFile = "/sound_wav/win.wav";
/*    */     }
/*    */     
/*    */     try {
/* 63 */       this.audioIn = AudioSystem.getAudioInputStream(getClass().getResource(pFile));
/* 64 */       this.clip = AudioSystem.getClip();
/* 65 */       this.clip.open(this.audioIn);
/* 66 */       this.clip.loop(-1);
/* 67 */       this.clip.start();
/*    */     }
/* 69 */     catch (Exception e) {
/* 70 */       e.printStackTrace();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\User\\unaip\Downloads\PokémonBattleArena.jar!\model\MusicManager.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */