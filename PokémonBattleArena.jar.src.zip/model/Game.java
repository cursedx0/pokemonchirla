/*    */ package model;
/*    */ 
/*    */ import java.util.Observable;
/*    */ import java.util.Timer;
/*    */ import java.util.TimerTask;
/*    */ 
/*    */ public class Game
/*    */   extends Observable {
/*  9 */   private static Game game = null;
/* 10 */   private Timer timer = null;
/*    */   
/*    */   private int timerMilisecs;
/*    */   
/*    */   public static Game getGame() {
/* 15 */     if (game == null) {
/* 16 */       game = new Game();
/*    */     }
/* 18 */     return game;
/*    */   }
/*    */   
/*    */   public void initPlayers(int pPlayers, int pBot, int miliSecs, int pNumAsciiMon) {
/* 22 */     this.timerMilisecs = miliSecs;
/* 23 */     int c = 0;
/* 24 */     for (int i = 0; i < pPlayers; i++) {
/* 25 */       Player p = new Player(pNumAsciiMon);
/* 26 */       PlayerList.getPlayerList().addPlayer(p);
/* 27 */       setChanged();
/* 28 */       notifyObservers(new Object[] { Integer.valueOf(i), p.getName(), Integer.valueOf(pNumAsciiMon) });
/* 29 */       c++;
/*    */     } 
/* 31 */     for (int j = 0; j < pBot; j++) {
/* 32 */       Bot b = new Bot(pNumAsciiMon);
/* 33 */       PlayerList.getPlayerList().addPlayer(b);
/* 34 */       setChanged();
/* 35 */       notifyObservers(new Object[] { Integer.valueOf(c + j), b.getName(), Integer.valueOf(pNumAsciiMon) });
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void startGame() {
/* 47 */     TimerTask timerTask = new TimerTask()
/*    */       {
/*    */         public void run() {
/* 50 */           PlayerList.getPlayerList().playRound();
/*    */         }
/*    */       };
/* 53 */     this.timer = new Timer();
/* 54 */     this.timer.scheduleAtFixedRate(timerTask, 0L, this.timerMilisecs);
/*    */   } public void stopGame() {
/* 56 */     this.timer.cancel(); this.timer.purge();
/*    */   }
/*    */ }


/* Location:              C:\User\\unaip\Downloads\PokémonBattleArena.jar!\model\Game.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */