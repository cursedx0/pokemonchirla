/*    */ package model;
/*    */ 
/*    */ import java.util.Observable;
/*    */ import java.util.Random;
/*    */ import model.poke.PokeFactory;
/*    */ import model.poke.PokeType;
/*    */ import model.poke.Pokemon;
/*    */ import model.poke.PokemonList;
/*    */ 
/*    */ public class Player
/*    */   extends Observable {
/* 12 */   protected static int count = 0;
/*    */   private String name;
/*    */   private boolean turn = false;
/*    */   private boolean defeated = false;
/* 16 */   private PokemonList pokemonList = new PokemonList();
/* 17 */   private int nChanges = 3;
/* 18 */   private Random rand = new Random();
/*    */   
/*    */   public Player(int pNumAsciiMon) {
/* 21 */     count++;
/* 22 */     this.name = "player" + count;
/* 23 */     for (int x = 0; x < pNumAsciiMon; x++) {
/* 24 */       Pokemon poke = PokeFactory.getPokeFactory().createPokemon(PokeType.values()[this.rand.nextInt((PokeType.values()).length)], x);
/* 25 */       this.pokemonList.addPokemon(poke);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void updatePokemons() {
/* 30 */     this.pokemonList.updatePokemons();
/*    */   }
/*    */   
/*    */   public PokemonList getPokemonList() {
/* 34 */     return this.pokemonList;
/*    */   }
/*    */   
/*    */   public String getName() {
/* 38 */     return this.name;
/*    */   }
/*    */   public boolean getTurn() {
/* 41 */     return this.turn;
/*    */   }
/*    */   public void setName(String pName) {
/* 44 */     this.name = pName;
/*    */   }
/*    */   protected int getNChanges() {
/* 47 */     return this.nChanges;
/*    */   }
/*    */   public void changePoke(Pokemon attacks, Pokemon pk) {
/* 50 */     getPokemonList().switchPoke(attacks, pk);
/* 51 */     System.out.println("Switching Poke!");
/* 52 */     restNChanges();
/*    */   }
/*    */   public void restNChanges() {
/* 55 */     if (this.nChanges > 0) {
/*    */       
/* 57 */       this.nChanges--;
/* 58 */       setChanged();
/* 59 */       notifyObservers(new Object[] { Boolean.valueOf(this.turn), Integer.valueOf(this.nChanges) });
/* 60 */       updatePokemons();
/*    */     } 
/*    */   }
/*    */   
/*    */   public int getAsciiMonListSize() {
/* 65 */     return getPokemonList().getSize();
/*    */   }
/*    */ 
/*    */   
/*    */   public void play() {}
/*    */   
/*    */   public boolean isTurn() {
/* 72 */     return this.turn;
/*    */   }
/*    */   
/*    */   public void setTurn(boolean turn) {
/* 76 */     this.turn = turn;
/* 77 */     setChanged();
/* 78 */     notifyObservers(new Object[] { Boolean.valueOf(this.turn), Integer.valueOf(this.nChanges) });
/*    */   }
/*    */   
/*    */   public boolean getDefeated() {
/* 82 */     return this.defeated;
/*    */   }
/*    */   
/*    */   public void setDefeated(boolean defeated) {
/* 86 */     this.defeated = defeated;
/* 87 */     setChanged();
/* 88 */     notifyObservers(new Object[] { Boolean.valueOf(this.turn), Integer.valueOf(this.nChanges) });
/*    */   }
/*    */ }


/* Location:              C:\User\\unaip\Downloads\PokémonBattleArena.jar!\model\Player.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */