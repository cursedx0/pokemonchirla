/*    */ package model;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.Random;
/*    */ import java.util.Timer;
/*    */ import java.util.stream.Collectors;
/*    */ 
/*    */ public class PlayerList
/*    */ {
/* 11 */   private static PlayerList playerList = null;
/* 12 */   private ArrayList<Player> pList = new ArrayList<>();
/* 13 */   Timer timer = null;
/*    */ 
/*    */ 
/*    */   
/*    */   public static PlayerList getPlayerList() {
/* 18 */     if (playerList == null) {
/* 19 */       playerList = new PlayerList();
/*    */     }
/* 21 */     return playerList;
/*    */   }
/*    */   public void addPlayer(Player pPlayer) {
/* 24 */     this.pList.add(pPlayer);
/*    */   }
/*    */   public void delPlayer(Player pPlayer) {
/* 27 */     this.pList.remove(pPlayer);
/*    */   }
/*    */   public Player findName(String pName) {
/* 30 */     Iterator<Player> itr = getIterator();
/* 31 */     boolean f = true;
/* 32 */     Player p = null;
/* 33 */     while (itr.hasNext() && f) {
/* 34 */       p = itr.next();
/* 35 */       if (p.getName().equals(pName)) {
/* 36 */         f = false;
/*    */       }
/*    */     } 
/* 39 */     return p;
/*    */   }
/*    */   private Iterator<Player> getIterator() {
/* 42 */     return this.pList.iterator();
/*    */   }
/*    */   public Player getPosPlayer(int idx) {
/* 45 */     return this.pList.get(idx);
/*    */   }
/*    */   
/*    */   public Player getRandomPlayer(Player pPlayer) {
/* 49 */     boolean found = false;
/* 50 */     Player p = null;
/* 51 */     while (!found) {
/* 52 */       Random rand = new Random();
/* 53 */       p = this.pList.get(rand.nextInt(this.pList.size()));
/* 54 */       if (!p.equals(pPlayer) && !p.getDefeated()) {
/* 55 */         found = true;
/*    */       }
/*    */     } 
/* 58 */     return p;
/*    */   }
/*    */   public boolean thereIsWinner() {
/* 61 */     return ((int)this.pList.stream().filter(p -> p.getDefeated()).count() == this.pList.size() - 1);
/*    */   }
/*    */   
/*    */   public boolean playRound() {
/* 65 */     boolean end = false;
/* 66 */     Iterator<Player> itr = getIterator();
/* 67 */     while (itr.hasNext()) {
/* 68 */       Player p = itr.next();
/* 69 */       p.setTurn(false);
/*    */     } 
/*    */     
/* 72 */     Player current = getRandomPlayer(null);
/* 73 */     current.setTurn(true);
/* 74 */     current.play();
/* 75 */     if (!(current instanceof Bot)) {
/* 76 */       Game.getGame().stopGame();
/*    */     }
/* 78 */     if (thereIsWinner()) {
/* 79 */       System.out.println((new StringBuilder())
/*    */ 
/*    */           
/* 82 */           .append(this.pList.stream().filter(p -> !p.getDefeated()).map(p -> p.getName()).collect(Collectors.toList()))
/* 83 */           .append(" is the Winner!").toString());
/* 84 */       end = true;
/* 85 */       current.setDefeated(false);
/* 86 */       MusicManager.getMusicManager().playMusic(2);
/* 87 */       Game.getGame().stopGame();
/*    */     } 
/* 89 */     return end;
/*    */   }
/*    */ }


/* Location:              C:\User\\unaip\Downloads\PokémonBattleArena.jar!\model\PlayerList.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */