/*    */ package model;
/*    */ 
/*    */ import model.poke.Pokemon;
/*    */ 
/*    */ public class BattleManager {
/*  6 */   private static BattleManager battleManager = null;
/*    */   private Player attacksPlayer;
/*    */   private Pokemon attacksPokemon;
/*    */   private Player defendsPlayer;
/*    */   private Pokemon defendsPokemon;
/*    */   
/*    */   public static BattleManager getBattleManager() {
/* 13 */     if (battleManager == null) {
/* 14 */       battleManager = new BattleManager();
/*    */     }
/* 16 */     return battleManager;
/*    */   }
/*    */   public void setAttacksPlayer(Player attacksPlayer) {
/* 19 */     this.attacksPlayer = attacksPlayer;
/*    */   }
/*    */   public void setAttacksPokemon(Pokemon attacksPokemon) {
/* 22 */     this.attacksPokemon = attacksPokemon;
/*    */   }
/*    */   public Player getAttacksPlayer() {
/* 25 */     return this.attacksPlayer;
/*    */   }
/*    */   public Pokemon getAttacksPokemon() {
/* 28 */     return this.attacksPokemon;
/*    */   }
/*    */   public void setDefendsPlayer(Player defendsPlayer) {
/* 31 */     this.defendsPlayer = defendsPlayer;
/*    */   }
/*    */   public void setDefendsPokemon(Pokemon defendsPokemon) {
/* 34 */     this.defendsPokemon = defendsPokemon;
/*    */   }
/*    */   private void reset() {
/* 37 */     this.attacksPlayer = null;
/* 38 */     this.attacksPokemon = null;
/* 39 */     this.defendsPlayer = null;
/* 40 */     this.defendsPokemon = null;
/*    */   }
/*    */   
/*    */   public boolean attack() {
/* 44 */     boolean allOK = true;
/* 45 */     if (this.attacksPlayer != null && this.defendsPlayer != null && this.attacksPokemon != null && this.defendsPokemon != null) {
/* 46 */       System.out.println(" -> " + this.attacksPlayer.getName() + " " + this.attacksPokemon.getPos() + " attacking " + this.defendsPlayer.getName() + " " + this.defendsPokemon.getPos());
/* 47 */       int pepsi = this.defendsPokemon.attack(this.attacksPokemon.getAtt(), this.attacksPokemon.getType());
/* 48 */       if (pepsi <= 0) {
/* 49 */         System.out.println("  -> Fainted! :|");
/*    */       }
/* 51 */       if (this.defendsPlayer.getPokemonList().allFainted()) {
/* 52 */         this.defendsPlayer.setDefeated(true);
/*    */       }
/* 54 */       this.attacksPokemon.notCharged();
/* 55 */       reset();
/*    */     } else {
/*    */       
/* 58 */       allOK = false;
/* 59 */       System.out.println(" -> Missing info for performing the attack!");
/*    */     } 
/* 61 */     return allOK;
/*    */   }
/*    */ }


/* Location:              C:\User\\unaip\Downloads\PokémonBattleArena.jar!\model\BattleManager.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */