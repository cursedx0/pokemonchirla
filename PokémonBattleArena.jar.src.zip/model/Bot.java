/*    */ package model;
/*    */ 
/*    */ import java.util.Random;
/*    */ import model.poke.Pokemon;
/*    */ 
/*    */ public class Bot
/*    */   extends Player {
/*    */   public Bot(int pNumAsciiMon) {
/*  9 */     super(pNumAsciiMon);
/* 10 */     setName("npc@TraiNer" + Player.count);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void play() {
/* 16 */     for (Pokemon attacks : getPokemonList().getNonFainted()) {
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 23 */       Player defendsPlayer = PlayerList.getPlayerList().getRandomPlayer(this);
/* 24 */       Pokemon defends = defendsPlayer.getPokemonList().getNonFainted().get((new Random()).nextInt(defendsPlayer.getPokemonList().getNonFainted().size()));
/* 25 */       BattleManager.getBattleManager().setAttacksPokemon(attacks);
/* 26 */       BattleManager.getBattleManager().setDefendsPokemon(defends);
/* 27 */       BattleManager.getBattleManager().setAttacksPlayer(this);
/* 28 */       BattleManager.getBattleManager().setDefendsPlayer(defendsPlayer);
/* 29 */       BattleManager.getBattleManager().attack();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\User\\unaip\Downloads\PokémonBattleArena.jar!\model\Bot.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */