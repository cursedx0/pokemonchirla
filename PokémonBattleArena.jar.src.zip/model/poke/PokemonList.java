/*    */ package model.poke;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.stream.Collectors;
/*    */ 
/*    */ public class PokemonList
/*    */ {
/* 10 */   private ArrayList<Pokemon> pList = new ArrayList<>();
/*    */ 
/*    */   
/*    */   public void addPokemon(Pokemon pPokemon) {
/* 14 */     this.pList.add(pPokemon);
/*    */   }
/*    */   public void delPokemon(Pokemon pPokemon) {
/* 17 */     this.pList.remove(pPokemon);
/*    */   }
/*    */   
/*    */   public void switchPoke(Pokemon thisPoke, Pokemon toThisPoke) {
/* 21 */     int pos = thisPoke.getPos();
/*    */     
/* 23 */     thisPoke.deleteObservers();
/* 24 */     delPokemon(thisPoke);
/* 25 */     this.pList.add(pos, toThisPoke);
/*    */   }
/*    */   
/*    */   private Iterator<Pokemon> getIterator() {
/* 29 */     return this.pList.iterator();
/*    */   }
/*    */   public Pokemon getPokemonInPos(int pPos) {
/* 32 */     return this.pList.get(pPos);
/*    */   }
/*    */   public int getSize() {
/* 35 */     return this.pList.size();
/*    */   }
/*    */   public List<Pokemon> getNonFainted() {
/* 38 */     return (List<Pokemon>)this.pList.stream().filter(p -> !p.getFainted()).collect(Collectors.toList());
/*    */   }
/*    */   public boolean allFainted() {
/* 41 */     return this.pList.stream().allMatch(p -> p.getFainted());
/*    */   }
/*    */   public void updatePokemons() {
/* 44 */     Iterator<Pokemon> itr = getIterator();
/* 45 */     while (itr.hasNext()) {
/* 46 */       Pokemon am = itr.next();
/* 47 */       am.updateInfo();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\User\\unaip\Downloads\PokémonBattleArena.jar!\model\poke\PokemonList.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */