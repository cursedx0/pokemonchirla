/*     */ package model.poke;
/*     */ 
/*     */ import java.util.Observable;
/*     */ import java.util.Random;
/*     */ import model.poke.evoState.Charged;
/*     */ import model.poke.evoState.IEvoState;
/*     */ import model.poke.evoState.LevelOne;
/*     */ import model.poke.evoState.LevelTwo;
/*     */ import model.poke.evoState.LevelZero;
/*     */ 
/*     */ public abstract class Pokemon
/*     */   extends Observable
/*     */ {
/*     */   private int att;
/*     */   private int def;
/*     */   private int hp;
/*     */   private int maxHp;
/*     */   private int pos;
/*     */   private int chargedMax;
/*     */   private int chargedCurrent;
/*     */   private boolean fainted = false;
/*  22 */   protected Random rand = new Random();
/*     */   protected PokeType type;
/*  24 */   private IEvoState evoState = (IEvoState)new LevelZero();
/*     */   
/*     */   public Pokemon(int pos) {
/*  27 */     this.att = 11 + this.rand.nextInt(7) + 1;
/*  28 */     this.def = 3 + this.rand.nextInt(3) + 1;
/*  29 */     this.hp = 200 + this.rand.nextInt(21) + 1;
/*  30 */     this.maxHp = this.hp;
/*  31 */     this.pos = pos;
/*  32 */     this.chargedMax = this.rand.nextInt(3) + 4;
/*  33 */     this.chargedCurrent = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   protected abstract int attackBoost(PokeType paramPokeType);
/*     */   
/*     */   public int attack(int attD, PokeType type) {
/*  40 */     int typeM = attackBoost(type);
/*  41 */     int dam = typeM * attD - getDef();
/*  42 */     if (dam < 0) {
/*  43 */       dam = 0;
/*     */     }
/*  45 */     System.out.println("  -> att:" + attD + " typeM:" + typeM + "x -def:" + this.def + " = " + dam);
/*  46 */     if (typeM >= 2) System.out.println("  -> is super effective!"); 
/*  47 */     this.hp -= dam;
/*  48 */     if (this.hp <= 0) {
/*  49 */       setFainted(true);
/*     */     }
/*  51 */     if (this.chargedCurrent < this.chargedMax) {
/*  52 */       this.chargedCurrent++;
/*     */     } else {
/*     */       
/*  55 */       this.chargedCurrent = this.chargedMax;
/*     */     } 
/*  57 */     checkState();
/*  58 */     updateInfo();
/*  59 */     return this.hp;
/*     */   }
/*     */   
/*     */   public void notCharged() {
/*  63 */     if (this.evoState instanceof Charged) {
/*  64 */       this.chargedCurrent = 0;
/*  65 */       checkState();
/*  66 */       updateInfo();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void checkState() {
/*  71 */     if (this.hp > this.maxHp / 2) {
/*  72 */       changeEvoState((IEvoState)new LevelZero());
/*     */     }
/*  74 */     if (this.hp <= this.maxHp / 2) {
/*  75 */       changeEvoState((IEvoState)new LevelOne());
/*     */     }
/*  77 */     if (this.hp <= this.maxHp / 4) {
/*  78 */       changeEvoState((IEvoState)new LevelTwo());
/*     */     }
/*  80 */     if (this.chargedCurrent == this.chargedMax) {
/*  81 */       changeEvoState((IEvoState)new Charged());
/*     */     }
/*     */   }
/*     */   
/*     */   public int getAtt() {
/*  86 */     return this.att + this.evoState.boostAtt();
/*     */   }
/*     */   public int getDef() {
/*  89 */     return this.def + this.evoState.boostDef();
/*     */   }
/*     */   private void changeEvoState(IEvoState pState) {
/*  92 */     this.evoState = pState;
/*     */   }
/*     */   public int getPos() {
/*  95 */     return this.pos;
/*     */   }
/*     */   public PokeType getType() {
/*  98 */     return this.type;
/*     */   }
/*     */   public void updateInfo() {
/* 101 */     setChanged();
/* 102 */     notifyObservers(new String[] { String.valueOf(Integer.toString(this.att)) + "+" + Integer.toString(this.evoState.boostAtt()), String.valueOf(Integer.toString(this.def)) + "+" + Integer.toString(this.evoState.boostDef()), Integer.toString(this.hp), Integer.toString(this.maxHp), this.type.toString(), Integer.toString(this.evoState.evo()), Integer.toString(this.chargedMax), Integer.toString(this.chargedCurrent) });
/*     */   }
/*     */   public boolean getFainted() {
/* 105 */     return this.fainted;
/*     */   }
/*     */   private void setFainted(boolean fainted) {
/* 108 */     this.fainted = fainted;
/*     */   }
/*     */ }


/* Location:              C:\User\\unaip\Downloads\PokémonBattleArena.jar!\model\poke\Pokemon.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */