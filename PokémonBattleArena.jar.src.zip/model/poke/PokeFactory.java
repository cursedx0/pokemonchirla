/*    */ package model.poke;
/*    */ 
/*    */ public class PokeFactory {
/*  4 */   private static PokeFactory pokeFactory = null;
/*    */ 
/*    */   
/*    */   public static PokeFactory getPokeFactory() {
/*  8 */     if (pokeFactory == null) {
/*  9 */       pokeFactory = new PokeFactory();
/*    */     }
/* 11 */     return pokeFactory;
/*    */   }
/*    */   public Pokemon createPokemon(PokeType type, int pos) {
/* 14 */     Pokemon poke = null;
/* 15 */     System.out.println("PokeFactory -> " + type.toString());
/* 16 */     if (type == PokeType.GRASS) {
/* 17 */       poke = new GrassPokemon(pos);
/*    */     }
/* 19 */     if (type == PokeType.FIRE) {
/* 20 */       poke = new FirePokemon(pos);
/*    */     }
/* 22 */     if (type == PokeType.WATER) {
/* 23 */       poke = new WaterPokemon(pos);
/*    */     }
/* 25 */     if (type == PokeType.ELECTRIC) {
/* 26 */       poke = new ElectricPokemon(pos);
/*    */     }
/* 28 */     if (type == PokeType.BUG) {
/* 29 */       poke = new BugPokemon(pos);
/*    */     }
/* 31 */     if (type == PokeType.PSYCHIC) {
/* 32 */       poke = new PsychicPokemon(pos);
/*    */     }
/* 34 */     if (type == PokeType.FIGHTING) {
/* 35 */       poke = new FightingPokemon(pos);
/*    */     }
/* 37 */     if (type == PokeType.ROCK) {
/* 38 */       poke = new RockPokemon(pos);
/*    */     }
/* 40 */     if (type == PokeType.GHOST) {
/* 41 */       poke = new GhostPokemon(pos);
/*    */     }
/* 43 */     if (type == PokeType.DRAGON) {
/* 44 */       poke = new DragonPokemon(pos);
/*    */     }
/* 46 */     if (type == PokeType.FLYING) {
/* 47 */       poke = new FlyingPokemon(pos);
/*    */     }
/* 49 */     return poke;
/*    */   }
/*    */ }


/* Location:              C:\User\\unaip\Downloads\PokémonBattleArena.jar!\model\poke\PokeFactory.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */