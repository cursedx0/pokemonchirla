/*    */ package model.poke;
/*    */ 
/*    */ public class DragonPokemon
/*    */   extends Pokemon {
/*    */   public DragonPokemon(int pos) {
/*  6 */     super(pos);
/*  7 */     this.type = PokeType.DRAGON;
/*    */   }
/*    */ 
/*    */   
/*    */   protected int attackBoost(PokeType type) {
/* 12 */     int mod = 1;
/* 13 */     if (type.equals(PokeType.DRAGON)) {
/* 14 */       mod = this.rand.nextInt(2) + 2;
/*    */     }
/* 16 */     return mod;
/*    */   }
/*    */ }


/* Location:              C:\User\\unaip\Downloads\PokémonBattleArena.jar!\model\poke\DragonPokemon.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */