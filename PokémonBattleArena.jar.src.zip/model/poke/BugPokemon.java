/*    */ package model.poke;
/*    */ 
/*    */ public class BugPokemon
/*    */   extends Pokemon {
/*    */   public BugPokemon(int pos) {
/*  6 */     super(pos);
/*  7 */     this.type = PokeType.BUG;
/*    */   }
/*    */ 
/*    */   
/*    */   protected int attackBoost(PokeType type) {
/* 12 */     int mod = 1;
/* 13 */     if (type.equals(PokeType.FIRE) || type.equals(PokeType.FLYING) || type.equals(PokeType.ROCK)) {
/* 14 */       mod = this.rand.nextInt(2) + 2;
/*    */     }
/* 16 */     return mod;
/*    */   }
/*    */ }


/* Location:              C:\User\\unaip\Downloads\PokémonBattleArena.jar!\model\poke\BugPokemon.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */