/*    */ package model.poke;
/*    */ 
/*    */ public class PsychicPokemon
/*    */   extends Pokemon {
/*    */   public PsychicPokemon(int pos) {
/*  6 */     super(pos);
/*  7 */     this.type = PokeType.PSYCHIC;
/*    */   }
/*    */ 
/*    */   
/*    */   protected int attackBoost(PokeType type) {
/* 12 */     int mod = 1;
/* 13 */     if (type.equals(PokeType.BUG) || type.equals(PokeType.GHOST)) {
/* 14 */       mod = this.rand.nextInt(2) + 2;
/*    */     }
/* 16 */     return mod;
/*    */   }
/*    */ }


/* Location:              C:\User\\unaip\Downloads\PokémonBattleArena.jar!\model\poke\PsychicPokemon.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */