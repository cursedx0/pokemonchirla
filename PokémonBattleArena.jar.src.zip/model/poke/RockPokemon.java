/*    */ package model.poke;
/*    */ 
/*    */ public class RockPokemon
/*    */   extends Pokemon {
/*    */   public RockPokemon(int pos) {
/*  6 */     super(pos);
/*  7 */     this.type = PokeType.ROCK;
/*    */   }
/*    */ 
/*    */   
/*    */   protected int attackBoost(PokeType type) {
/* 12 */     int mod = 1;
/* 13 */     if (type.equals(PokeType.WATER) || type.equals(PokeType.GRASS) || type.equals(PokeType.FIGHTING)) {
/* 14 */       mod = this.rand.nextInt(2) + 2;
/*    */     }
/* 16 */     return mod;
/*    */   }
/*    */ }


/* Location:              C:\User\\unaip\Downloads\PokémonBattleArena.jar!\model\poke\RockPokemon.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */