/*   */ package model.poke;
/*   */ 
/*   */ public enum StatusType {
/* 4 */   NONE,
/* 5 */   BURNED,
/* 6 */   PARALYZED,
/* 7 */   CONFUSED,
/* 8 */   POISONED;
/*   */ }


/* Location:              C:\User\\unaip\Downloads\PokémonBattleArena.jar!\model\poke\StatusType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */