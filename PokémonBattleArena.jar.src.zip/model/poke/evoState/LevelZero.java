/*    */ package model.poke.evoState;
/*    */ 
/*    */ public class LevelZero implements IEvoState {
/*  4 */   private int batt = 0;
/*  5 */   private int bdef = 0;
/*  6 */   private int evo = 0;
/*    */   
/*    */   public int boostAtt() {
/*  9 */     return this.batt;
/*    */   }
/*    */   
/*    */   public int boostDef() {
/* 13 */     return this.bdef;
/*    */   }
/*    */   
/*    */   public int evo() {
/* 17 */     return this.evo;
/*    */   }
/*    */ }


/* Location:              C:\User\\unaip\Downloads\PokémonBattleArena.jar!\model\poke\evoState\LevelZero.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */