package model.poke.evoState;

public interface IEvoState {
  int boostAtt();
  
  int boostDef();
  
  int evo();
}


/* Location:              C:\User\\unaip\Downloads\PokémonBattleArena.jar!\model\poke\evoState\IEvoState.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */