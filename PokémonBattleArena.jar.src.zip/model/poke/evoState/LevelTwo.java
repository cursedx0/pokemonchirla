/*    */ package model.poke.evoState;
/*    */ 
/*    */ public class LevelTwo implements IEvoState {
/*  4 */   private int batt = 7;
/*  5 */   private int bdef = 5;
/*  6 */   private int evo = 2;
/*    */   
/*    */   public int boostAtt() {
/*  9 */     return this.batt;
/*    */   }
/*    */   
/*    */   public int boostDef() {
/* 13 */     return this.bdef;
/*    */   }
/*    */   
/*    */   public int evo() {
/* 17 */     return this.evo;
/*    */   }
/*    */ }


/* Location:              C:\User\\unaip\Downloads\PokémonBattleArena.jar!\model\poke\evoState\LevelTwo.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */