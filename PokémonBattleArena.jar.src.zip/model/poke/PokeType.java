/*    */ package model.poke;
/*    */ 
/*    */ public enum PokeType {
/*  4 */   FIRE,
/*  5 */   GRASS,
/*  6 */   ELECTRIC,
/*  7 */   WATER,
/*  8 */   BUG,
/*  9 */   PSYCHIC,
/* 10 */   FIGHTING,
/* 11 */   ROCK,
/* 12 */   GHOST,
/* 13 */   DRAGON,
/* 14 */   FLYING;
/*    */ }


/* Location:              C:\User\\unaip\Downloads\PokémonBattleArena.jar!\model\poke\PokeType.class
 * Java compiler version: 11 (55.0)
 * JD-Core Version:       1.1.3
 */