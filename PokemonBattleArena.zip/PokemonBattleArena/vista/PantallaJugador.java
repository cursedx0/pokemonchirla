package vista;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import java.util.Observer;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controlador.ControladorBotonGo;
import modelo.Jugador;
import modelo.ListaJugadores;

import java.awt.BorderLayout;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.GridLayout;

@SuppressWarnings({ "serial", "deprecation" })
public class PantallaJugador extends JFrame implements Observer{
	private JPanel contentPane;
	private JPanel panelBotonFoto;
	private JButton btnGo;
	private JPanel panelPokemons;
	private JLabel lblImagen;
	private JPanel panelBotones;
	private Random random = new Random();
	private int numPokemons;
	private int idJugador;
	private ControladorBotonGo controler = ControladorBotonGo.getGestor();
	private List<PanelPokemon> listaPaneles = new ArrayList<>();

	/**
	 * Create the frame.
	 */
	public PantallaJugador(int pNumPokemons, String pNombre, int idJugador) {
		this.idJugador = idJugador;
		this.numPokemons = pNumPokemons;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		contentPane.add(getPanelBotonFoto(), BorderLayout.WEST);
		contentPane.add(getPanelPokemons(), BorderLayout.CENTER);
		this.setTitle(pNombre);
		this.setBackground(Color.WHITE);
		this.setVisible(true);
		for(int i = 0; i<numPokemons;i++) {
			PanelPokemon panel = new PanelPokemon(idJugador , i);
			panelPokemons.add(panel);
			listaPaneles.add(panel)	;		
		}
	}

	private JPanel getPanelBotonFoto() {
		if (panelBotonFoto == null) {
			panelBotonFoto = new JPanel();
			panelBotonFoto.setLayout(new BorderLayout(0, 0));
			panelBotonFoto.add(getPanelBotones(), BorderLayout.NORTH);
			panelBotonFoto.add(getLblImagen(), BorderLayout.CENTER);
		}
		return panelBotonFoto;
	}
	
	private JPanel getPanelBotones() {
		if(panelBotones == null) {
			panelBotones = new JPanel();
			panelBotones.setLayout(new GridLayout(1, 0, 0, 0));
			panelBotones.add(getBtnGo());
		}
		return panelBotones;
	}
	public JPanel getPanelPokemons() {
		
		if (panelPokemons == null) {
			panelPokemons = new JPanel();
			panelPokemons.setLayout(new GridLayout(0,this.numPokemons, 1, 1));
		}
		return panelPokemons;
	}
	private JButton getBtnGo() {
		if (btnGo == null) {
			btnGo = new JButton("GO!");
			btnGo.setBackground(Color.GREEN);
			btnGo.setForeground(Color.BLACK);
			btnGo.addActionListener(controler);
		}
		return btnGo;
	}
	
	private JLabel getLblImagen() {
		if (lblImagen == null) {
			ImageIcon imagen = new ImageIcon(this.getClass().getResource(Imagenes.getImagenes().obtenerFoto("Entrenador"+this.random.nextInt(6))));
			lblImagen = new JLabel(imagen);
		}
		return lblImagen;
	}
	
	public void eliminarPantalla() {
		this.setVisible(false);
	}

	@Override
	public void update(Observable o, Object arg) {
		// TODO Auto-generated method stub
		if(o instanceof Jugador) {
			boolean[] array = (boolean[]) arg;
			if(array[1] == true) {
				this.eliminarPantalla();
				ListaJugadores.getListaJugadores().eliminarJugador(ListaJugadores.getListaJugadores().getJugadorPos(this.idJugador));

			}
			if(array[0]) {
				this.getBtnGo().setText("GO!");
				this.getBtnGo().setForeground(Color.BLACK);
				this.getBtnGo().setBackground(Color.GREEN);
				this.getBtnGo().setEnabled(true);
				this.getPanelPokemons().setEnabled(true);
			}
			else {
				this.getBtnGo().setText("WAIT!");
				this.getBtnGo().setForeground(Color.BLACK);
				this.getBtnGo().setBackground(Color.RED);
				this.getBtnGo().setEnabled(false);
				this.getPanelPokemons().setEnabled(false);
			}
		}
		
}}