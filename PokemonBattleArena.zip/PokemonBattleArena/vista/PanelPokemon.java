package vista;

import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.JTextArea;
import javax.swing.JLabel;
import javax.swing.JProgressBar;
import java.awt.GridLayout;
import java.util.Observable;
import java.util.Observer;

import javax.swing.SwingConstants;

import modelo.Pokemon;

public class PanelPokemon extends JPanel implements Observer{
	private JTextArea txtrAtaque;
	private JLabel lblImagen;
	private JProgressBar progressBarVida;
	private JProgressBar progressBarEuforia;
	private JPanel panel;
	private String texto;

	/**
	 * Create the panel.
	 */
	public PanelPokemon(Pokemon pPokemon) {
		setLayout(new BorderLayout(0, 0));
		add(getTxtrAtaque(), BorderLayout.NORTH);
		add(getLblImagen(), BorderLayout.CENTER);
		add(getPanel(), BorderLayout.SOUTH);
		this.setBackground(Color.WHITE);

	}

	private JTextArea getTxtrAtaque() {
		if (txtrAtaque == null) {
			txtrAtaque = new JTextArea();
			txtrAtaque.setText(texto);
		}
		return txtrAtaque;
	}
	private JLabel getLblImagen() {
		if (lblImagen == null) {
			lblImagen = new JLabel("imagen");
			lblImagen.setHorizontalAlignment(SwingConstants.CENTER);
		}
		return lblImagen;
	}
	private JProgressBar getProgressBarVida() {
		if (progressBarVida == null) {
			progressBarVida = new JProgressBar();
		}
		return progressBarVida;
	}
	private JProgressBar getProgressBarEuforia() {
		if (progressBarEuforia == null) {
			progressBarEuforia = new JProgressBar();
		}
		return progressBarEuforia;
	}
	private JPanel getPanel() {
		if (panel == null) {
			panel = new JPanel();
			panel.setLayout(new GridLayout(0, 1, 1, 2));
			panel.add(getProgressBarVida());
			panel.add(getProgressBarEuforia());
		}
		return panel;
	}

	@Override
	public void update(Observable o, Object arg) {
		// TODO Auto-generated method stub
		if(o instanceof Pokemon) {
			String[] array = (String[]) arg;
			this.txtrAtaque.setText("Ataque: " +array[0] +"\nDefensa: " +array[1] +"\nVida: " +array[2] +"/" +array[3] +"\nTipo: " +array[4]);
		}
	}
}
