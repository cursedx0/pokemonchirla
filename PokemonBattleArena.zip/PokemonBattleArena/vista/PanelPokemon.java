package vista;

import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.JTextArea;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JProgressBar;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Observable;
import java.util.Observer;

import javax.swing.SwingConstants;

import modelo.Bot;
import modelo.ListaJugadores;
import modelo.Pokemon;
import modelo.batalla;


public class PanelPokemon extends JPanel implements Observer{
	private JTextArea txtrAtaque;
	private JLabel lblImagen;
	private JProgressBar progressBarVida;
	private JProgressBar progressBarEuforia;
	private JPanel panel;
	private String texto;
	private String imagen;
	private int idJugador;
	private int idPokemon;
	private PanelPokemon.Controler controler = null;

	/**
	 * Create the panel.
	 */
	public PanelPokemon(int idJugador, int idPokemon) {
		this.idJugador = idJugador;
		this.idPokemon = idPokemon;
		setLayout(new BorderLayout(0, 0));
		add(getTxtrAtaque(), BorderLayout.NORTH);
		add(getLblImagen(), BorderLayout.CENTER);
		add(getPanel(), BorderLayout.SOUTH);
		this.setBackground(Color.WHITE);
	}

	private JTextArea getTxtrAtaque() {
		if (txtrAtaque == null) {
			txtrAtaque = new JTextArea();
			txtrAtaque.setText(texto);
			txtrAtaque.setEditable(false);
		}
		return txtrAtaque;
	}
	public JLabel getLblImagen() {
		if (lblImagen == null) {
			lblImagen = new JLabel("");
			}
			lblImagen.setBackground(Color.WHITE);
			lblImagen.setHorizontalAlignment(SwingConstants.CENTER);
			lblImagen.addMouseListener(this.getControler());
		return lblImagen;
	}
	private JProgressBar getProgressBarVida() {
		if (progressBarVida == null) {
			progressBarVida = new JProgressBar();
			progressBarVida.setStringPainted(true);
			progressBarVida.setString("VIDA");
			progressBarVida.setForeground(Color.BLACK);
		}
		return progressBarVida;
	}
	private JProgressBar getProgressBarEuforia() {
		if (progressBarEuforia == null) {
			progressBarEuforia = new JProgressBar();
			progressBarEuforia.setStringPainted(true);
			progressBarEuforia.setString("EUFORIA");
			progressBarEuforia.setForeground(Color.RED);
			
		}
		return progressBarEuforia;
	}
	private JPanel getPanel() {
		if (panel == null) {
			panel = new JPanel();
			panel.setLayout(new GridLayout(0, 1, 1, 2));
			panel.add(getProgressBarVida());
			panel.add(getProgressBarEuforia());
		}
		return panel;
	}
	
	 private PanelPokemon.Controler getControler() {
	        if (this.controler == null) {
	            this.controler = new PanelPokemon.Controler();
	        }

	        return this.controler;
	    }

	@Override
	public void update(Observable o, Object arg) {
		// TODO Auto-generated method stub
		if(o instanceof Pokemon) {
			String[] array = (String[]) arg;
			this.getTxtrAtaque().setText("Ataque: " +array[0] +"\nDefensa: " +array[1] +"\nVida: " +array[2] +"/" +array[3] +"\nTipo: " +array[4]);
			this.getProgressBarVida().setMaximum(Integer.parseInt(array[3]));
			this.getProgressBarVida().setValue(Integer.parseInt(array[2]));
			this.getProgressBarEuforia().setMaximum(Integer.parseInt(array[7]));
			this.getProgressBarEuforia().setValue(Integer.parseInt(array[6]));
			
			if(Integer.parseInt(array[5]) != 3) {
				this.imagen = Imagenes.getImagenes().obtenerFoto(array[4]+array[5]);
				//ImageIcon imagen = new ImageIcon(this.getClass().getResource(Imagenes.getImagenes().obtenerFoto(array[4]+Integer.parseInt(array[5]))));
				this.getLblImagen().setIcon(new ImageIcon(this.getClass().getResource(imagen)));
			}
				
			if(Integer.parseInt(array[2]) >= Integer.parseInt(array[3])/2) {
				this.getProgressBarVida().setForeground(Color.GREEN);
			}
			if(Integer.parseInt(array[2]) < Integer.parseInt(array[3])/2 && Integer.parseInt(array[2]) >= Integer.parseInt(array[3])/5) {
				this.getProgressBarVida().setForeground(Color.ORANGE);
			}
			if(Integer.parseInt(array[2]) < Integer.parseInt(array[3])/5) {
				this.getProgressBarVida().setForeground(Color.RED);
			}	
		}
	}
	
	 private class Controler implements MouseListener {
	        private Controler() {
	        }

	        public void mouseClicked(MouseEvent e) {
	            if (e.getSource().equals(PanelPokemon.this.lblImagen) && PanelPokemon.this.lblImagen.isEnabled() && ListaJugadores.getListaJugadores().getJugadorPos(PanelPokemon.this.idJugador).getTurno() && !(ListaJugadores.getListaJugadores().getJugadorPos(PanelPokemon.this.idJugador) instanceof Bot)) {
	                batalla.getBatalla().setJugadorAtacante(ListaJugadores.getListaJugadores().getJugadorPos(PanelPokemon.this.idJugador));
	                batalla.getBatalla().setPokemonatacante(ListaJugadores.getListaJugadores().getJugadorPos(PanelPokemon.this.idJugador).getListaPokemons().get(PanelPokemon.this.idPokemon));
	            } else {
	            	batalla.getBatalla().setJugadorDefensor(ListaJugadores.getListaJugadores().getJugadorPos(PanelPokemon.this.idJugador));
	            	batalla.getBatalla().setPokemonDefensor(ListaJugadores.getListaJugadores().getJugadorPos(PanelPokemon.this.idJugador).getListaPokemons().get(PanelPokemon.this.idPokemon));
	                batalla.getBatalla().atacar();
	            }

	        }

	        public void mouseEntered(MouseEvent arg0) {
	        }

	        public void mouseExited(MouseEvent arg0) {
	        }

	        public void mousePressed(MouseEvent arg0) {
	        }

	        public void mouseReleased(MouseEvent arg0) {
	        }
	    }
}
