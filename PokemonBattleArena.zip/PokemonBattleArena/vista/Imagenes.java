package vista;

import java.util.HashMap;

public class Imagenes {
	private static Imagenes imagenes = null;
	private HashMap<String, String> imagenesPokemons= new HashMap<>();
	
	private Imagenes() {
		this.imagenesPokemons.put("Entrenador0", "/imagenes/trainer0.png");
		this.imagenesPokemons.put("Entrenador1", "/imagenes/trainer1.png");
		this.imagenesPokemons.put("Entrenador2", "/imagenes/trainer2.png");
		this.imagenesPokemons.put("Entrenador3", "/imagenes/trainer3.png");
		this.imagenesPokemons.put("Entrenador4", "/imagenes/trainer4.png");
		this.imagenesPokemons.put("Entrenador5", "/imagenes/trainer5.png");
		this.imagenesPokemons.put("FUEGO0", "/imagenes/Fire/0charmander.png");
		this.imagenesPokemons.put("FUEGO1", "/imagenes/Fire/1charmeleon.png");
		this.imagenesPokemons.put("FUEGO2", "/imagenes/Fire/2charizard.png");
		this.imagenesPokemons.put("ELECTRICO0", "/imagenes/Electric/0pikachu.png");
		this.imagenesPokemons.put("ELECTRICO1", "/imagenes/Electric/1raichu.png");
		this.imagenesPokemons.put("ELECTRICO2", "/imagenes/Electric/2raichu2.png");
		this.imagenesPokemons.put("AGUA0", "/imagenes/Water/0squirtle.png");
		this.imagenesPokemons.put("AGUA1", "/imagenes/Water/1wartortle.png");
		this.imagenesPokemons.put("AGUA2", "/imagenes/Water/2blastoise.png");
		this.imagenesPokemons.put("PLANTA0", "/imagenes/Grass/0bulbasaur.png");
		this.imagenesPokemons.put("PLANTA1", "/imagenes/Grass/1ivysaur.png");
		this.imagenesPokemons.put("PLANTA2", "/imagenes/Grass/2venusaur.png");
	}
	
	public static Imagenes getImagenes() {
		if(imagenes == null) {
			imagenes = new Imagenes();
		}
		return imagenes;
	}
	
	public String obtenerFoto(String pClave) {
		return this.imagenesPokemons.get(pClave);
	}
}
