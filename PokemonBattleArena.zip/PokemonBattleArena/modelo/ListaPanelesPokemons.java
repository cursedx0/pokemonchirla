package modelo;

import java.util.ArrayList;
import java.util.List;

import vista.PanelPokemon;

public class ListaPanelesPokemons {
	private List<PanelPokemon> lista = new ArrayList<>();
	
	public ListaPanelesPokemons() {
		
	}
	
	public void anadirPanel(PanelPokemon pPanel) {
		this.lista.add(pPanel);
	}
	
	public PanelPokemon getPanelPos(int pPos) {
		return this.lista.get(pPos);
	}
	
	public int getTamaño() {
		return this.lista.size();
	}
}
