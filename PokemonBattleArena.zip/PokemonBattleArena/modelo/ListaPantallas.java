package modelo;

import java.util.ArrayList;
import java.util.List;

import vista.PantallaJugador;

public class ListaPantallas {
	private static ListaPantallas listaPantallas  = null;
	private List<PantallaJugador> lista = new ArrayList<>();
	
	public static ListaPantallas getLista() {
		if(listaPantallas == null) {
			listaPantallas = new ListaPantallas();
		}
		return listaPantallas;
	}
	
	public void anadirPantalla(PantallaJugador pPantalla) {
		this.lista.add(pPantalla);
	}
	
	public int getTamaño() {
		return this.lista.size();
	}
	
	public PantallaJugador getPantallaPos(int pPos) {
		return this.lista.get(pPos);
	}
}
