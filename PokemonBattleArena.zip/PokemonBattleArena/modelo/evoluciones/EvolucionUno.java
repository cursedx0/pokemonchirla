package modelo.evoluciones;

public class EvolucionUno implements Evoluciones{
	
	private int ataque = 5;
	private int defensa = 3;
	private int evolucion = 1;
	
	public EvolucionUno() {
		
	}

	public int bonoAtaque() {
		// TODO Auto-generated method stub
		return this.ataque;
	}

	public int bonoDefensa() {
		// TODO Auto-generated method stub
		return this.defensa;
	}

	public int evolucion() {
		// TODO Auto-generated method stub
		return this.evolucion;
	}

}
