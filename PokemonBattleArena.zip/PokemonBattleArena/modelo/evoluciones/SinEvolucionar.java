package modelo.evoluciones;

public class SinEvolucionar implements Evoluciones{
	
	private int ataque = 0;
	private int defensa = 0;
	private int evolucion = 0;
	
	public SinEvolucionar() {
		
	}

	public int bonoAtaque() {
		// TODO Auto-generated method stub
		return this.ataque;
	}

	public int bonoDefensa() {
		// TODO Auto-generated method stub
		return this.defensa;
	}

	public int evolucion() {
		// TODO Auto-generated method stub
		return this.evolucion;
	}

}
