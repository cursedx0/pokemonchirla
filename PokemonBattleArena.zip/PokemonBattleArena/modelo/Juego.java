package modelo;

import java.util.Observable;
import java.util.Timer;


public class Juego extends Observable{
	private static Juego juego = null;
	private Timer timer;
	private int miliSeg;
	
	public Juego() {
		
	}
	
	public static Juego getJuego() {
		if(juego == null) {
			juego = new Juego();
		}
		return juego;
	}
	
	public void iniciarPartida(int numJugadores, int numBots, int miliSeg, int numPokemons) {
		int num = 0;
		for(int i = 0;i<numJugadores; i++) {
			Jugador jugador = new Jugador(numPokemons);
			ListaJugadores.getListaJugadores().anadirJugador(jugador);
			this.setChanged();
			this.notifyObservers(new Object[] {i, jugador.getNombre(), numPokemons});
			num++;
		}
		for(int j = 0;j<numBots; j++) {
			Bot bot = new Bot(numPokemons);
			ListaJugadores.getListaJugadores().anadirJugador(bot);
			this.setChanged();
			this.notifyObservers(new Object[] {j+num, bot.getNombre(), numPokemons});
		}
		batalla.getBatalla().asignarTurno();
	}
}
