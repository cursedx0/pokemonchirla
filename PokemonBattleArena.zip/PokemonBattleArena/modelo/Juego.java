package modelo;

import java.util.Observable;
import java.util.Timer;

public class Juego extends Observable{
	private static Juego juego = null;
	private Timer timer;
	private int miliSeg;
	
	public Juego() {
		
	}
	
	public static Juego getJuego() {
		if(juego == null) {
			juego = new Juego();
		}
		return juego;
	}
	
	public void iniciarJugadores(int numJugadores, int numBots, int miliSeg, int numPokemons) {
		int id = 0;
		this.miliSeg = miliSeg;
		
		for(int i = 0;i<numJugadores; i++) {
			Jugador jugador = new Jugador(numPokemons);
			ListaJugadores.getListaJugadores().anadirJugador(jugador);
			this.setChanged();
			this.notifyObservers(new Object[] {});
		}
		for(int j = 0;j<numBots; j++) {
			Bot bot = new Bot(numPokemons);
			ListaJugadores.getListaJugadores().anadirJugador(bot);
			this.setChanged();
			this.notifyObservers(new Object[] {});
		}
	}
}
