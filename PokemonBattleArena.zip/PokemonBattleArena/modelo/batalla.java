package modelo;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class batalla {
	private static batalla pBatalla = null;
	private Jugador jugadorAtacante;
	private Jugador jugadorDefensor;
	private Pokemon pokemonAtacante;
	private Pokemon pokemonDefensor;
	private Random random = new Random();
	
	public static batalla getBatalla() {
		if(pBatalla == null) {
			pBatalla = new batalla();
		}
		return pBatalla;
	}

	public void setJugadorAtacante(Jugador pJugador) {
		this.jugadorAtacante = pJugador;
	}
	public void setJugadorDefensor(Jugador pJugador) {
		this.jugadorDefensor = pJugador;
	}
	public void setPokemonatacante(Pokemon pPokemon) {
		this.pokemonAtacante = pPokemon;
	}
	public void setPokemonDefensor(Pokemon pPokemon) {
		this.pokemonDefensor = pPokemon;
	}
	public Pokemon getPokemonAtacante() {
		return this.pokemonAtacante;
	}
	public Pokemon getPokemonDefensor() {
		return this.pokemonDefensor;
	}
	
	public void reiniciar() {
		this.jugadorAtacante = null;
		this.jugadorDefensor = null;
		this.pokemonAtacante = null;
		this.pokemonDefensor = null;
	}

	public void asignarTurno() {
		int i = random.nextInt(ListaJugadores.getListaJugadores().tamañoLista());
		
		for(int j = 0; j<ListaJugadores.getListaJugadores().tamañoLista();j++) {
			if(ListaJugadores.getListaJugadores().getJugadorPos(j) != ListaJugadores.getListaJugadores().getJugadorPos(i)) {
				ListaJugadores.getListaJugadores().getJugadorPos(j).setTurno(false);
			}
			else {
				ListaJugadores.getListaJugadores().getJugadorPos(i).setTurno(true);
				ListaJugadores.getListaJugadores().getJugadorPos(i).jugarTurno();
				for(int x = 0; x<ListaJugadores.getListaJugadores().getJugadorPos(i).getListaPokemons().size();x++) {
					ListaJugadores.getListaJugadores().getJugadorPos(i).getListaPokemons().get(x).reiniciarAtaque();
				}
				
			}
		}
	}
	
	public boolean atacar() {
		boolean correcto = true;
		if(pokemonAtacante != null && pokemonDefensor != null && this.jugadorAtacante != null && this.jugadorDefensor != null && correcto && this.pokemonAtacante.yaHaAtacado() == false) {
			pokemonDefensor.recibirAtaque(pokemonAtacante.getAtaque(), pokemonAtacante.getTipo());
			this.pokemonAtacante.quitarEuforia();
			this.pokemonAtacante.ataqueHecho(true);
			this.reiniciar();
			correcto = true;
		}
		else {
			correcto = false;
		}
		
		return correcto;
	}
}

