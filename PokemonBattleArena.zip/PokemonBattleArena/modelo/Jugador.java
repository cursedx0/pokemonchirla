package modelo;

import java.util.Random;
import java.util.stream.Collectors;

import vista.PantallaJugador;

import static java.util.stream.IntStream.range;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Observable;
public class Jugador extends Observable{
	protected static int num = 0;
	private String nombre;
	private Random random = new Random();
	private List<Pokemon> listaPokemons = new ArrayList<>();
	private boolean derrotado = false;
	public boolean turno = false;
	private int ataquesRestantes;
	public Jugador(int numPokemons) {
		num++;
		this.ataquesRestantes = numPokemons;
		this.nombre = "Jugador"+num;
		for(int i = 0; i<numPokemons;i++) {
			Pokemon pokemon = CrearPokemons.getCrearPokemons().crear(i, Tipo.values()[this.random.nextInt(Tipo.values().length)]);
			this.listaPokemons.add(pokemon);
		}
		
	}
	
	public String getNombre() {
		return this.nombre;
	}
	
	public List<Pokemon> getListaPokemons() {
		return this.listaPokemons;
	}
	
	public void setDerrotado(boolean pDerrotado) {
		this.derrotado = pDerrotado;
	}
	
	public boolean getTurno() {
		
		return this.turno;
	}
	
	public void setTurno(boolean pTurno) {
		this.turno = pTurno;
		actualizarInfo();
		
	}
	
	public void setNombre(String pString) {
		this.nombre = pString;
	}
	
	protected Iterator<Pokemon> iterator(){
		return this.listaPokemons.iterator();
	}
	public void jugarTurno() {
		
	}
	
	public List<Pokemon> getNoDerrotados() {
        return (List)this.getListaPokemons().stream().filter((p) -> {
            return !p.getDerrotado();
        }).collect(Collectors.toList());
    }
	
	public void actualizarPokemons() {
		Iterator it = this.iterator();
		while(it.hasNext()) {
			Pokemon p = (Pokemon) it.next();
			p.actualizarInfo();
		}
	}
	
	public void atacar() {
		if(this.ataquesRestantes > 0) {
			ataquesRestantes--;
			this.actualizarInfo();
			this.actualizarPokemons();
		}
	}

	public void actualizarInfo() {
		this.setChanged();
		this.notifyObservers(new boolean[] {this.getTurno()});
	}
}


