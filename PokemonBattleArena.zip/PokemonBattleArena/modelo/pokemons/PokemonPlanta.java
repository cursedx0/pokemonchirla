package modelo.pokemons;

import modelo.Pokemon;
import modelo.Tipo;

public class PokemonPlanta extends Pokemon{

	public PokemonPlanta(int posicion) {
		super(posicion,Tipo.PLANTA);
		// TODO Auto-generated constructor stub
	}

}
