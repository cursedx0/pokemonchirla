package modelo.pokemons;

import modelo.Pokemon;
import modelo.Tipo;

public class PokemonAgua extends Pokemon{
	
	public PokemonAgua(int posicion) {
		super(posicion, Tipo.AGUA);
	}

}
