package modelo.pokemons;

import modelo.Pokemon;
import modelo.Tipo;

public class PokemonFuego extends Pokemon{

	public PokemonFuego(int posicion) {
		super(posicion,Tipo.FUEGO);
		// TODO Auto-generated constructor stub
	}

}
