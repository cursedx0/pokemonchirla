package modelo.pokemons;

import modelo.Pokemon;
import modelo.Tipo;

public class PokemonTierra extends Pokemon{

	public PokemonTierra(int posicion) {
		super(posicion,Tipo.TIERRA);
		// TODO Auto-generated constructor stub
	}

}
