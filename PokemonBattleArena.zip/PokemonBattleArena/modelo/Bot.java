package modelo;

public class Bot extends Jugador{

	private static int contador;
	private String nombre;
	public Bot(int numPokemons) {
		super(numPokemons);
		// TODO Auto-generated constructor stub
	}


}
