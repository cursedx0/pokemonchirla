package modelo;

import java.util.Iterator;
import java.util.Random;

public class Bot extends Jugador{

	public Bot(int numPokemons) {
		super(numPokemons);
		super.setNombre("Bot"+Jugador.num);
		// TODO Auto-generated constructor stub
	}

	public void jugarTurno() {
		Iterator<Pokemon> it = super.iterator();
		if(ListaJugadores.getListaJugadores().tamañoLista()	>= 2) {
			while(it.hasNext()) {
				Pokemon atacante = (Pokemon) it.next();
				Jugador defensor = ListaJugadores.getListaJugadores().getJugadorAleatorio(this);
				Pokemon pdefensor = defensor.getNoDerrotados().get(new Random().nextInt(defensor.getNoDerrotados().size()));
				Batalla.getBatalla().setPokemonatacante(atacante);
				Batalla.getBatalla().setPokemonDefensor(pdefensor);
				Batalla.getBatalla().setJugadorAtacante(this);
				Batalla.getBatalla().setJugadorDefensor(defensor);
				Batalla.getBatalla().atacar();
		}	
		}
		Batalla.getBatalla().asignarTurno();
	}
}
