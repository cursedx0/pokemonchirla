package modelo;

import java.util.Iterator;
import java.util.Random;

public class Bot extends Jugador{

	public Bot(int numPokemons) {
		super(numPokemons);
		super.setNombre("Bot"+Jugador.num);
		// TODO Auto-generated constructor stub
	}

	public void jugarTurno() {
		Iterator<Pokemon> it = super.iterator();
	
		while(it.hasNext()) {
			Pokemon atacante = (Pokemon) it.next();
			Jugador defensor = ListaJugadores.getListaJugadores().getJugadorAleatorio(this);
			Pokemon pdefensor = defensor.getListaPokemons().get(new Random().nextInt(defensor.getNoDerrotados().size()));
			batalla.getBatalla().setPokemonatacante(atacante);
			batalla.getBatalla().setPokemonDefensor(pdefensor);
			batalla.getBatalla().setJugadorAtacante(this);
			batalla.getBatalla().setJugadorDefensor(defensor);
			batalla.getBatalla().atacar();
		}
		batalla.getBatalla().asignarTurno();
	}
}
