package evoluciones;

public interface Evoluciones {
	
	int bonoAtaque();
	
	int bonoDefensa();
	
	int evoluvion();
		
}
