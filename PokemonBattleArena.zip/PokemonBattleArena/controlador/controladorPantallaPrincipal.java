package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


import modelo.Juego;
import vista.PantallaPrincipal;

public class controladorPantallaPrincipal implements ActionListener{
	private static controladorPantallaPrincipal controlador = null;
	
	public static controladorPantallaPrincipal getControlador() {
		if(controlador == null) {
			controlador = new controladorPantallaPrincipal();
		}
		return controlador;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		Juego.getJuego().iniciarPartida(Integer.parseInt(PantallaPrincipal.getPantallaPrincipal().getNumJugadores()), Integer.parseInt(PantallaPrincipal.getPantallaPrincipal().getNumBots()), Integer.parseInt(PantallaPrincipal.getPantallaPrincipal().getMiliSeg()), Integer.parseInt(PantallaPrincipal.getPantallaPrincipal().getNumPokemons()));
		PantallaPrincipal.getPantallaPrincipal().setVisible(false);
	}

}


