package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import modelo.Juego;
import modelo.Jugador;
import modelo.ListaJugadores;
import modelo.ListaPantallas;
import vista.PantallaJugador;
import vista.PantallaPrincipal;

public class controladorPantallaPrincipal implements ActionListener{
	private static controladorPantallaPrincipal controlador = null;
	
	private Random random = new Random();
	
	public static controladorPantallaPrincipal getControlador() {
		if(controlador == null) {
			controlador = new controladorPantallaPrincipal();
		}
		return controlador;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		
		int posJugador = 0;
		int numBot = 0;
		PantallaJugador pb;
		PantallaJugador pb1;
		Juego.getJuego().iniciarPartida(Integer.parseInt(PantallaPrincipal.getPantallaPrincipal().getNumJugadores()), Integer.parseInt(PantallaPrincipal.getPantallaPrincipal().getNumBots()), Integer.parseInt(PantallaPrincipal.getPantallaPrincipal().getMiliSeg()), PantallaPrincipal.getPantallaPrincipal().getNumPokemons());
		for(int i = 0; i<Integer.parseInt(PantallaPrincipal.getPantallaPrincipal().getNumJugadores());i++) {
			pb = new PantallaJugador(PantallaPrincipal.getPantallaPrincipal().getNumPokemons(), "Jugador"+(i+1), ListaJugadores.getListaJugadores().getJugadorPos(posJugador));
			ListaPantallas.getLista().anadirPantalla(pb);
			pb.setVisible(true);
			posJugador++;
		}
		for(int j = 0;j<Integer.parseInt(PantallaPrincipal.getPantallaPrincipal().getNumBots());j++) {
			pb1 = new PantallaJugador(PantallaPrincipal.getPantallaPrincipal().getNumPokemons(), "Bot"+(j+1), ListaJugadores.getListaJugadores().getJugadorPos(posJugador));
			ListaPantallas.getLista().anadirPantalla(pb1);
			ListaJugadores.getListaJugadores().getJugadorPos(posJugador).setNombre("Bot"+(numBot+1));
			pb1.setVisible(true);
			numBot++;
			posJugador++;
		}	
		gestorPartida.getGestor().asignarTurno();
	}

}


