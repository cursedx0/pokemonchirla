package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import modelo.Jugador;
import modelo.ListaJugadores;
import modelo.ListaPokemons;
import modelo.Pokemon;

public class gestorPartida implements ActionListener{
	private static gestorPartida gestor = null;
	private Random random = new Random();
	
	public gestorPartida() {
		
	}
	
	public static gestorPartida getGestor() {
		if(gestor == null) {
			gestor = new gestorPartida();
		}
		return gestor;
	}

	
	public void asignarTurno() {
		int i = random.nextInt(ListaJugadores.getListaJugadores().tamañoLista());
		
		for(int j = 0; j<ListaJugadores.getListaJugadores().tamañoLista();j++) {
			if(ListaJugadores.getListaJugadores().getJugadorPos(j) != ListaJugadores.getListaJugadores().getJugadorPos(i)) {
				ListaJugadores.getListaJugadores().getJugadorPos(j).setTurno(false);
			}
			else {
				ListaJugadores.getListaJugadores().getJugadorPos(i).setTurno(true);
				gestorBotonAtacar.getGestorBotonAtacar().setJugadorAtacante(ListaJugadores.getListaJugadores().getJugadorPos(i));
			}
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		this.asignarTurno();
	}
}
