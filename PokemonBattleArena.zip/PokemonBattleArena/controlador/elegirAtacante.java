package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import modelo.Jugador;
import modelo.ListaPantallas;

public class elegirAtacante implements ActionListener{
	private static elegirAtacante elegir = null;
	private Jugador pJugador = gestorBotonAtacar.getGestorBotonAtacar().getJugadorAtacante();
	
	public static elegirAtacante getPokemon() {
		if(elegir == null) {
			elegir = new elegirAtacante();
		}
		return elegir;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
			for(int i = 0; i<ListaPantallas.getLista().getTamaño(); i++) {
				if(ListaPantallas.getLista().getPantallaPos(i).getJugador().getTurno() == true) {
					
				}
			}
	}
}
