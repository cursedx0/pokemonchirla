package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import modelo.Batalla;
import modelo.ListaJugadores;

public class ControladorBotonGo implements ActionListener{
	private static ControladorBotonGo gestor = null;
	
	public ControladorBotonGo() {
		
	}
	
	public static ControladorBotonGo getGestor() {
		if(gestor == null) {
			gestor = new ControladorBotonGo();
		}
		return gestor;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(ListaJugadores.getListaJugadores().tamañoLista() >= 2) {
			Batalla.getBatalla().asignarTurno();
		}
		else {
			JOptionPane.showMessageDialog(null, "El ganador es: " + ListaJugadores.getListaJugadores().getJugadorPos(0).getNombre());
		}
	}
}
