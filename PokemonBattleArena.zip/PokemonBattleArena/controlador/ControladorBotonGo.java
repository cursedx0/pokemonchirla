package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import modelo.batalla;

public class ControladorBotonGo implements ActionListener{
	private static ControladorBotonGo gestor = null;
	
	public ControladorBotonGo() {
		
	}
	
	public static ControladorBotonGo getGestor() {
		if(gestor == null) {
			gestor = new ControladorBotonGo();
		}
		return gestor;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		batalla.getBatalla().asignarTurno();
	}
}
