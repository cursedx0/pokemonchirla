package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


import modelo.Juego;
import vista.PantallaPrincipal;

public class ControladorPantallaPrincipal implements ActionListener{
	private static ControladorPantallaPrincipal controlador = null;
	
	public static ControladorPantallaPrincipal getControlador() {
		if(controlador == null) {
			controlador = new ControladorPantallaPrincipal();
		}
		return controlador;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		Juego.getJuego().iniciarPartida(Integer.parseInt(PantallaPrincipal.getPantallaPrincipal().getNumJugadores()), Integer.parseInt(PantallaPrincipal.getPantallaPrincipal().getNumBots()), Integer.parseInt(PantallaPrincipal.getPantallaPrincipal().getMiliSeg()), Integer.parseInt(PantallaPrincipal.getPantallaPrincipal().getNumPokemons()));
		PantallaPrincipal.getPantallaPrincipal().setVisible(false);
	}

}


