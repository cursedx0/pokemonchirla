package controlador;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

public class ControladorBotonReadMe implements ActionListener{
	private static ControladorBotonReadMe controlador = null;
	
	public static ControladorBotonReadMe get() {
		if(controlador == null) {
			controlador = new ControladorBotonReadMe();
		}
		return controlador;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		JOptionPane.showMessageDialog(null, "Para iniciar la partida llena todos los campos y luego dale al boton Free4All");
	}
	
}
