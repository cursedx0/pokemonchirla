package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.xml.crypto.dsig.spec.SignatureMethodParameterSpec;

import modelo.Jugador;
import modelo.ListaJugadores;
import modelo.Pokemon;

public class gestorBotonAtacar implements ActionListener{
	private static gestorBotonAtacar gestor = null;
	private Jugador jAtacante;
	private Pokemon pAtacante;
	private Pokemon pDefensor;
	
	public static gestorBotonAtacar getGestorBotonAtacar() {
		if(gestor == null) {
			gestor = new gestorBotonAtacar();
		}
		return gestor;
	}
	
	public void setJugadorAtacante(Jugador pJugador) {
		this.jAtacante = pJugador;
	}
	
	public void setPokemonAtacante(Pokemon pPokemon) {
		this.pAtacante = pPokemon;
	}
	
	public void setPokemonDefensor(Pokemon pPokemon) {
		this.pDefensor = pPokemon;
	}
	
	public Jugador getJugadorAtacante() {
		return this.jAtacante;
	}
	
	public Pokemon getPokemonAtacante() {
		return this.pAtacante;
	}
	
	public Pokemon getPokemonDefensor() {
		return this.pDefensor;
	}

	public void atacar(){
		if(this.jAtacante != null && this.pAtacante != null && this.pDefensor != null) {
			this.pDefensor.recibirAtaque(this.pAtacante.getAtaque(), this.pAtacante.getTipo());
			this.pAtacante.quitarEuforia();
		}
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		for(int i = 0; i<ListaJugadores.getListaJugadores().tamañoLista(); i++) {
			if(ListaJugadores.getListaJugadores().getJugadorPos(i) != this.getJugadorAtacante()) {
				for(int j = 0; j<ListaJugadores.getListaJugadores().getJugadorPos(i).getListaPokemons().getTamaño(); j++) {
				
				}
			}
		};
		System.out.println("El jugador atacante es: " +this.getJugadorAtacante().getNombre());
	}

}
